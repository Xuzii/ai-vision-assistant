import { useState, useEffect, useCallback } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { motion, AnimatePresence } from "motion/react";
import { CameraFeed } from "./components/CameraFeed";
import { ActivityCard } from "./components/ActivityCard";
import type { ActivityCategory } from "./components/ActivityCard";
import { CameraActivityBar } from "./components/CameraActivityBar";
import { AnalyticsChart } from "./components/AnalyticsChart";
import { ProcessManager } from "./components/ProcessManager";
import { CostMonitor } from "./components/CostMonitor";
import { VoiceQuery } from "./components/VoiceQuery";
import { RoomMap } from "./components/RoomMap";
import { ObjectTracker } from "./components/ObjectTracker";
import { Timeline } from "./components/Timeline";
import { Login } from "./components/Login";
import { Settings } from "./components/Settings";
import { ConnectionStatus } from "./components/ConnectionStatus";
import { TodayOverview } from "./components/TodayOverview";
import { Badge } from "./components/ui/badge";
import { Button } from "./components/ui/button";
import { EyeIcon, ChartIcon, SettingsIcon, ShieldIcon, FilterIcon, MapIcon, ClockIcon } from "./components/icons";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";
import { useSettings } from "./components/hooks/useSettings";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ActivityCategory | "All">("All");
  const [isConnectionLost, setIsConnectionLost] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [failedCamerasCount, setFailedCamerasCount] = useState(0);
  
  // Cameras state - must be declared before any conditional returns
  const [cameras, setCameras] = useState([
    { id: "1", name: "Living Room", location: "Main Floor", isConnected: true },
    { id: "2", name: "Kitchen", location: "Main Floor", isConnected: true },
    { id: "3", name: "Office", location: "Second Floor", isConnected: false },
    { id: "4", name: "Gym", location: "Basement", isConnected: true },
  ]);
  
  // Settings hook
  const { settings, setDarkMode, setRefreshInterval } = useSettings();

  // Handler functions - using useCallback to prevent dependency issues
  const handleGlobalReconnect = useCallback(() => {
    setIsReconnecting(true);
    // Simulate reconnection attempt
    setTimeout(() => {
      setIsReconnecting(false);
      // In a real app, this would check if reconnection succeeded
      // For demo, we'll just stop the reconnecting state
    }, 3000);
  }, []);

  // Monitor camera connections
  useEffect(() => {
    const failedCameras = cameras.filter(c => !c.isConnected).length;
    setFailedCamerasCount(failedCameras);
    setIsConnectionLost(failedCameras > 0);
  }, [cameras]);

  // Simulate auto-reconnect with exponential backoff
  useEffect(() => {
    if (isConnectionLost && !isReconnecting) {
      const timer = setTimeout(() => {
        handleGlobalReconnect();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isConnectionLost, isReconnecting, handleGlobalReconnect]);

  // Auto-refresh based on settings
  useEffect(() => {
    if (settings.refreshInterval > 0 && isAuthenticated) {
      const interval = setInterval(() => {
        console.log('Auto-refreshing data...');
        // In a real app, this would fetch new data
      }, settings.refreshInterval);
      
      return () => clearInterval(interval);
    }
  }, [settings.refreshInterval, isAuthenticated]);

  const handleLogin = (username: string, password: string) => {
    // Simple authentication - in production, this would validate against a backend
    if (username && password) {
      setIsLoading(true);
      // Simulate loading time for smooth transition
      setTimeout(() => {
        setIsAuthenticated(true);
        setIsLoading(false);
      }, 2000);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  // Loading transition screen
  if (isLoading) {
    return (
      <motion.div 
        className="min-h-screen bg-background flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="mb-6"
          >
            <div className="relative inline-flex items-center justify-center">
              {/* Outer ring */}
              <motion.div
                className="absolute w-32 h-32 border-4 border-primary/20 rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              />
              {/* Middle ring */}
              <motion.div
                className="absolute w-24 h-24 border-4 border-accent/30 rounded-full border-t-accent"
                animate={{ rotate: -360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              />
              {/* Inner ring */}
              <motion.div
                className="absolute w-16 h-16 border-4 border-primary/40 rounded-full border-t-primary"
                animate={{ rotate: 360 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
              />
              {/* Center icon */}
              <motion.div 
                className="relative p-4 rounded-2xl bg-primary shadow-[var(--elevation-sm)]"
                animate={{ 
                  scale: [1, 1.1, 1],
                }}
                transition={{ 
                  duration: 2, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <EyeIcon className="w-8 h-8 text-primary-foreground" />
              </motion.div>
            </div>
          </motion.div>
          
          <motion.h3
            className="mb-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            Initializing Vision System
          </motion.h3>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-center gap-2"
          >
            <motion.div
              className="w-2 h-2 bg-primary rounded-full"
              animate={{ 
                scale: [1, 1.5, 1],
                opacity: [1, 0.5, 1]
              }}
              transition={{ 
                duration: 1, 
                repeat: Infinity,
                delay: 0
              }}
            />
            <motion.div
              className="w-2 h-2 bg-primary rounded-full"
              animate={{ 
                scale: [1, 1.5, 1],
                opacity: [1, 0.5, 1]
              }}
              transition={{ 
                duration: 1, 
                repeat: Infinity,
                delay: 0.2
              }}
            />
            <motion.div
              className="w-2 h-2 bg-primary rounded-full"
              animate={{ 
                scale: [1, 1.5, 1],
                opacity: [1, 0.5, 1]
              }}
              transition={{ 
                duration: 1, 
                repeat: Infinity,
                delay: 0.4
              }}
            />
          </motion.div>
          
          <motion.div
            className="mt-6 space-y-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
          >
            <motion.p 
              className="text-sm opacity-70"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              🔐 Authenticating...
            </motion.p>
            <motion.p 
              className="text-sm opacity-70"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
            >
              📡 Connecting to cameras...
            </motion.p>
            <motion.p 
              className="text-sm opacity-70"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
            >
              🧠 Starting AI models...
            </motion.p>
          </motion.div>
        </div>
      </motion.div>
    );
  }

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  // Mock data
  const activities = [
    {
      person: "John",
      location: "Living Room",
      activity: "Working on laptop, typing actively",
      category: "Productivity" as ActivityCategory,
      timestamp: "2 min ago",
      tokens: 1250,
      cost: 0.0025,
      thumbnail: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&h=300&fit=crop"
    },
    {
      person: "Sarah",
      location: "Gym",
      activity: "Running on treadmill, HR: 145 bpm",
      category: "Health" as ActivityCategory,
      timestamp: "5 min ago",
      tokens: 980,
      cost: 0.0019,
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop"
    },
    {
      person: "John",
      location: "Kitchen",
      activity: "Preparing coffee, standing at counter",
      category: "Other" as ActivityCategory,
      timestamp: "15 min ago",
      tokens: 850,
      cost: 0.0017,
      thumbnail: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=300&fit=crop"
    },
    {
      person: "Sarah",
      location: "Living Room",
      activity: "Watching TV, sitting on couch",
      category: "Entertainment" as ActivityCategory,
      timestamp: "32 min ago",
      tokens: 920,
      cost: 0.0018,
      thumbnail: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400&h=300&fit=crop"
    },
    {
      person: "Both",
      location: "Kitchen",
      activity: "Having breakfast together, conversing",
      category: "Social" as ActivityCategory,
      timestamp: "1 hour ago",
      tokens: 1100,
      cost: 0.0022,
      thumbnail: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=300&fit=crop"
    },
  ];

  const analyticsData = [
    { day: "Mon", Productivity: 180, Health: 45, Entertainment: 90, Social: 30, Other: 60 },
    { day: "Tue", Productivity: 240, Health: 60, Entertainment: 60, Social: 45, Other: 45 },
    { day: "Wed", Productivity: 200, Health: 90, Entertainment: 75, Social: 60, Other: 50 },
    { day: "Thu", Productivity: 220, Health: 45, Entertainment: 100, Social: 30, Other: 55 },
    { day: "Fri", Productivity: 160, Health: 75, Entertainment: 120, Social: 90, Other: 40 },
    { day: "Sat", Productivity: 80, Health: 120, Entertainment: 180, Social: 120, Other: 80 },
    { day: "Sun", Productivity: 60, Health: 90, Entertainment: 200, Social: 100, Other: 70 },
  ];

  const dailyAnalyticsData = [
    { time: "6AM", Productivity: 0, Health: 0, Entertainment: 0, Social: 0, Other: 15 },
    { time: "8AM", Productivity: 10, Health: 30, Entertainment: 0, Social: 15, Other: 5 },
    { time: "10AM", Productivity: 45, Health: 0, Entertainment: 5, Social: 5, Other: 5 },
    { time: "12PM", Productivity: 30, Health: 0, Entertainment: 10, Social: 20, Other: 0 },
    { time: "2PM", Productivity: 40, Health: 0, Entertainment: 15, Social: 0, Other: 5 },
    { time: "4PM", Productivity: 35, Health: 0, Entertainment: 20, Social: 5, Other: 0 },
    { time: "6PM", Productivity: 20, Health: 45, Entertainment: 5, Social: 0, Other: 10 },
    { time: "8PM", Productivity: 0, Health: 0, Entertainment: 45, Social: 30, Other: 5 },
    { time: "10PM", Productivity: 0, Health: 0, Entertainment: 35, Social: 15, Other: 10 },
  ];

  const processes = [
    { id: "1", name: "Vision API Service", status: "running" as const, uptime: "4h 23m", cpu: 15, memory: 512 },
    { id: "2", name: "Camera Stream Handler", status: "running" as const, uptime: "4h 23m", cpu: 8, memory: 256 },
    { id: "3", name: "Activity Analyzer", status: "running" as const, uptime: "4h 20m", cpu: 22, memory: 768 },
    { id: "4", name: "Tailscale VPN", status: "running" as const, uptime: "12h 45m", cpu: 2, memory: 128 },
    { id: "5", name: "Token Counter", status: "stopped" as const, uptime: "0m", cpu: 0, memory: 0 },
  ];

  const trackedObjects = [
    { id: "1", name: "MacBook Pro", category: "Electronics", location: "Living Room", lastSeen: "2 min ago", confidence: 98, status: "present" as const },
    { id: "2", name: "iPhone", category: "Electronics", location: "Kitchen", lastSeen: "5 min ago", confidence: 95, status: "present" as const },
    { id: "3", name: "Car Keys", category: "Personal", location: "Kitchen", lastSeen: "15 min ago", confidence: 92, status: "present" as const },
    { id: "4", name: "Wallet", category: "Personal", location: "Living Room", lastSeen: "3 hours ago", confidence: 88, status: "missing" as const },
    { id: "5", name: "Coffee Maker", category: "Appliances", location: "Kitchen", lastSeen: "1 min ago", confidence: 99, status: "present" as const },
    { id: "6", name: "Yoga Mat", category: "Personal", location: "Gym", lastSeen: "30 min ago", confidence: 94, status: "present" as const },
    { id: "7", name: "Remote Control", category: "Electronics", location: "Living Room", lastSeen: "10 min ago", confidence: 91, status: "present" as const },
    { id: "8", name: "Water Bottle", category: "Personal", location: "Gym", lastSeen: "25 min ago", confidence: 89, status: "present" as const },
    { id: "9", name: "Backpack", category: "Personal", location: "Living Room", lastSeen: "5 hours ago", confidence: 85, status: "missing" as const },
  ];

  const roomsData = [
    { id: "1", name: "Living Room", objectCount: trackedObjects.filter(o => o.location === "Living Room" && o.status === "present").length },
    { id: "2", name: "Kitchen", objectCount: trackedObjects.filter(o => o.location === "Kitchen" && o.status === "present").length },
    { id: "3", name: "Office", objectCount: 0 },
    { id: "4", name: "Gym", objectCount: trackedObjects.filter(o => o.location === "Gym" && o.status === "present").length },
  ];

  const timelineActivities = [
    { time: "6:30 AM", person: "John", location: "Kitchen", activity: "Making breakfast, preparing coffee", category: "Other" as ActivityCategory, duration: "15 min" },
    { time: "7:00 AM", person: "Sarah", location: "Gym", activity: "Morning yoga session, stretching", category: "Health" as ActivityCategory, duration: "30 min" },
    { time: "7:45 AM", person: "Both", location: "Kitchen", activity: "Having breakfast together, planning the day", category: "Social" as ActivityCategory, duration: "20 min" },
    { time: "8:15 AM", person: "John", location: "Office", activity: "Morning standup call, video conference", category: "Productivity" as ActivityCategory, duration: "30 min" },
    { time: "9:00 AM", person: "Sarah", location: "Living Room", activity: "Reading news, browsing tablet", category: "Other" as ActivityCategory, duration: "25 min" },
    { time: "10:30 AM", person: "John", location: "Office", activity: "Working on project proposal, typing actively", category: "Productivity" as ActivityCategory, duration: "90 min" },
    { time: "12:00 PM", person: "Both", location: "Kitchen", activity: "Lunch together, watching cooking show", category: "Social" as ActivityCategory, duration: "35 min" },
    { time: "1:00 PM", person: "Sarah", location: "Gym", activity: "Cardio workout on treadmill, HR: 145 bpm", category: "Health" as ActivityCategory, duration: "45 min" },
    { time: "2:00 PM", person: "John", location: "Living Room", activity: "Working on laptop, video editing", category: "Productivity" as ActivityCategory, duration: "60 min" },
    { time: "3:30 PM", person: "Sarah", location: "Living Room", activity: "Video call with friends", category: "Social" as ActivityCategory, duration: "40 min" },
    { time: "4:30 PM", person: "John", location: "Kitchen", activity: "Coffee break, checking phone", category: "Other" as ActivityCategory, duration: "10 min" },
    { time: "5:00 PM", person: "Both", location: "Living Room", activity: "Watching a movie together", category: "Entertainment" as ActivityCategory, duration: "120 min" },
    { time: "7:15 PM", person: "John", location: "Kitchen", activity: "Preparing dinner, cooking", category: "Other" as ActivityCategory, duration: "35 min" },
    { time: "8:00 PM", person: "Both", location: "Kitchen", activity: "Having dinner, conversing", category: "Social" as ActivityCategory, duration: "40 min" },
    { time: "9:00 PM", person: "Sarah", location: "Living Room", activity: "Playing video games", category: "Entertainment" as ActivityCategory, duration: "60 min" },
    { time: "10:15 PM", person: "Both", location: "Living Room", activity: "Watching TV series together", category: "Entertainment" as ActivityCategory, duration: "45 min" },
  ];

  const filteredActivities = selectedCategory === "All" 
    ? activities 
    : activities.filter(a => a.category === selectedCategory);

  const handleReconnectCamera = (id: string) => {
    console.log("Reconnecting camera:", id);
  };

  const handleRestartProcess = (id: string) => {
    console.log("Restarting process:", id);
  };

  const handleStopProcess = (id: string) => {
    console.log("Stopping process:", id);
  };

  const handleStartProcess = (id: string) => {
    console.log("Starting process:", id);
  };

  const handleVoiceQuery = (query: string) => {
    console.log("Voice query:", query);
  };

  return (
    <motion.div 
      className="min-h-screen bg-background p-6 md:p-8 lg:p-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      {/* Connection Status Banner */}
      <ConnectionStatus 
        isConnected={!isConnectionLost}
        isReconnecting={isReconnecting}
        failedCameras={failedCamerasCount}
        onReconnect={handleGlobalReconnect}
      />
      
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          className="mb-8 md:mb-10"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5 mb-3">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <motion.div 
                  className="p-2.5 rounded-xl bg-primary shadow-[var(--elevation-sm)]"
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <EyeIcon className="w-6 h-6 text-primary-foreground" />
                </motion.div>
                <motion.h1 
                  className="mb-0"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  AI Vision Assistant
                </motion.h1>
              </div>
              <motion.p 
                className="opacity-70"
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.7 }}
                transition={{ delay: 0.3 }}
              >
                Person-focused tracking with smart analytics
              </motion.p>
            </div>
            <motion.div 
              className="flex flex-wrap items-center gap-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <motion.div whileHover={{ scale: 1.05 }}>
                <Badge variant="secondary" className="flex items-center gap-1.5 px-3 py-1.5 rounded-full">
                  <ShieldIcon className="w-3 h-3" />
                  Tailscale VPN
                </Badge>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }}>
                <Badge className="bg-chart-4 border-0 px-3 py-1.5 rounded-full shadow-[var(--elevation-sm)] text-white">
                  <span className="relative flex h-2 w-2 mr-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                  </span>
                  Live
                </Badge>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  onClick={handleLogout}
                  variant="outline"
                  className="rounded-xl border border-border hover:bg-primary/10 transition-colors"
                >
                  Logout
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>

        {/* Main Tabs */}
        <Tabs defaultValue="analytics" className="space-y-8 md:space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <TabsList className="w-full lg:w-auto p-2 bg-card backdrop-blur-sm shadow-[var(--elevation-sm)] border border-border grid grid-cols-3 md:grid-cols-6 lg:inline-grid lg:grid-cols-none lg:grid-flow-col gap-2">
            <TabsTrigger value="analytics" className="flex items-center justify-center gap-2 rounded-lg px-3 lg:px-6 py-3.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[var(--elevation-sm)] transition-all">
              <ChartIcon className="w-4 h-4" />
              <span className="hidden md:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="timeline" className="flex items-center justify-center gap-2 rounded-lg px-3 lg:px-6 py-3.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[var(--elevation-sm)] transition-all">
              <ClockIcon className="w-4 h-4" />
              <span className="hidden md:inline">Timeline</span>
            </TabsTrigger>
            <TabsTrigger value="tracking" className="flex items-center justify-center gap-2 rounded-lg px-3 lg:px-6 py-3.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[var(--elevation-sm)] transition-all">
              <EyeIcon className="w-4 h-4" />
              <span className="hidden md:inline">Tracking</span>
            </TabsTrigger>
            <TabsTrigger value="objects" className="flex items-center justify-center gap-2 rounded-lg px-3 lg:px-6 py-3.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[var(--elevation-sm)] transition-all">
              <MapIcon className="w-4 h-4" />
              <span className="hidden md:inline">Objects</span>
            </TabsTrigger>
            <TabsTrigger value="voice" className="flex items-center justify-center gap-2 rounded-lg px-3 lg:px-6 py-3.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[var(--elevation-sm)] transition-all">
              <FilterIcon className="w-4 h-4" />
              <span className="hidden md:inline">Voice</span>
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center justify-center gap-2 rounded-lg px-3 lg:px-6 py-3.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[var(--elevation-sm)] transition-all">
              <SettingsIcon className="w-4 h-4" />
              <span className="hidden md:inline">System</span>
            </TabsTrigger>
            </TabsList>
          </motion.div>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-8 md:space-y-6">
            <TodayOverview
              deskTime="3h 22m"
              uniqueActivities={4}
              percentChange={3}
              streak={7}
              categoryBreakdown={{
                productivity: 45,
                entertainment: 30,
                health: 25,
              }}
            />
            <AnalyticsChart data={analyticsData} dailyData={dailyAnalyticsData} />
            
            {/* Activity Stream */}
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5 mb-6">
                <h2>Recent Activities</h2>
                <Select value={selectedCategory} onValueChange={(value) => setSelectedCategory(value as ActivityCategory | "All")}>
                  <SelectTrigger className="w-full sm:w-[200px] rounded-xl border border-border bg-card backdrop-blur-sm shadow-[var(--elevation-sm)]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    <SelectItem value="All">📊 All Categories</SelectItem>
                    <SelectItem value="Productivity">💼 Productivity</SelectItem>
                    <SelectItem value="Health">💪 Health</SelectItem>
                    <SelectItem value="Entertainment">🎮 Entertainment</SelectItem>
                    <SelectItem value="Social">👥 Social</SelectItem>
                    <SelectItem value="Other">📌 Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 md:gap-4">
                {filteredActivities.map((activity, index) => (
                  <ActivityCard key={index} {...activity} />
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Timeline Tab */}
          <TabsContent value="timeline">
            <Timeline activities={timelineActivities} />
          </TabsContent>

          {/* Tracking Tab */}
          <TabsContent value="tracking" className="space-y-8 md:space-y-6">
            {/* Camera Feeds with Recent Activity */}
            <div>
              <h2 className="mb-6">Live Camera Feeds</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-4">
                {cameras.map((camera) => {
                  // Find the most recent activity for this camera location
                  const recentActivity = activities.find(a => a.location === camera.name);
                  
                  return (
                    <CameraFeed
                      key={camera.id}
                      {...camera}
                      onReconnect={() => handleReconnectCamera(camera.id)}
                      person={recentActivity?.person}
                      activity={recentActivity?.activity}
                      category={recentActivity?.category}
                      timestamp={recentActivity?.timestamp}
                      tokens={recentActivity?.tokens}
                    />
                  );
                })}
              </div>
            </div>
          </TabsContent>

          {/* Objects Tab */}
          <TabsContent value="objects" className="space-y-8 md:space-y-6">
            <RoomMap rooms={roomsData} />
            <ObjectTracker objects={trackedObjects} />
          </TabsContent>

          {/* Voice Tab */}
          <TabsContent value="voice">
            <VoiceQuery onQuery={handleVoiceQuery} />
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-8 md:space-y-6">
            <CostMonitor 
              dailySpent={1.47}
              dailyCap={2.00}
              totalTokens={15420}
              requestsToday={87}
            />
            <ProcessManager 
              processes={processes}
              onRestart={handleRestartProcess}
              onStop={handleStopProcess}
              onStart={handleStartProcess}
            />
            <Settings
              darkMode={settings.darkMode}
              refreshInterval={settings.refreshInterval}
              onDarkModeChange={setDarkMode}
              onRefreshIntervalChange={setRefreshInterval}
            />
          </TabsContent>
        </Tabs>
      </div>
    </motion.div>
  );
}
