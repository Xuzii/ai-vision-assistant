import { CameraIcon, RefreshIcon, WifiOffIcon } from "./icons";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useState } from "react";
import { motion } from "motion/react";
import { CameraActivityBar } from "./CameraActivityBar";
import type { ActivityCategory } from "./ActivityCard";

interface CameraFeedProps {
  id: string;
  name: string;
  location: string;
  isConnected: boolean;
  onReconnect: () => void;
  // Activity props
  person?: string;
  activity?: string;
  category?: ActivityCategory;
  timestamp?: string;
  tokens?: number;
}

export function CameraFeed({ id, name, location, isConnected, onReconnect, person, activity, category, timestamp, tokens }: CameraFeedProps) {
  const [reconnecting, setReconnecting] = useState(false);

  const handleReconnect = () => {
    setReconnecting(true);
    onReconnect();
    setTimeout(() => setReconnecting(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      whileHover={{ y: -4 }}
    >
      <Card className="overflow-hidden border border-border shadow-[var(--elevation-sm)] hover:shadow-2xl transition-all duration-300">
        {/* Camera Header */}
        <div className="p-4 bg-card flex items-center justify-between border-b border-border">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10 backdrop-blur-sm">
              <CameraIcon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h4 className="text-sm">{name}</h4>
              <p className="text-xs opacity-70">{location}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={isConnected ? "default" : "destructive"} className="text-xs px-2.5 py-0.5 rounded-full">
              {isConnected ? "Live" : "Offline"}
            </Badge>
            {!isConnected && (
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={handleReconnect}
                disabled={reconnecting}
                className="h-8 w-8 p-0 rounded-full"
              >
                <RefreshIcon className={`w-3 h-3 ${reconnecting ? 'animate-spin' : ''}`} />
              </Button>
            )}
          </div>
        </div>

        {/* Recent Activity Section */}
        <div className="px-4 py-2 bg-card border-b border-border">
          <CameraActivityBar
            person={person}
            activity={activity}
            category={category}
            timestamp={timestamp}
            tokens={tokens}
          />
        </div>

        {/* Camera Feed */}
        <div className="relative aspect-video bg-primary/5 flex items-center justify-center">
          {isConnected ? (
            <div className="absolute inset-0 bg-primary/10 flex items-center justify-center">
              <div className="text-center text-foreground">
                <div className="relative inline-flex items-center justify-center mb-3">
                  <div className="absolute w-16 h-16 bg-primary/20 rounded-full animate-ping"></div>
                  <CameraIcon className="w-10 h-10 relative text-primary" />
                </div>
                <p className="text-xs opacity-70">MJPEG Stream Active</p>
              </div>
            </div>
          ) : (
            <div className="text-center text-foreground">
              <WifiOffIcon className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p className="text-xs opacity-70">Camera Disconnected</p>
              <p className="text-xs mt-1 opacity-50">Retrying with exponential backoff...</p>
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
