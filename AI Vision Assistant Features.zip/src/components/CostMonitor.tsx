import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { DollarIcon, AlertIcon } from "./icons";
import { Alert, AlertDescription } from "./ui/alert";
import { motion } from "motion/react";

interface CostMonitorProps {
  dailySpent: number;
  dailyCap: number;
  totalTokens: number;
  requestsToday: number;
}

export function CostMonitor({ dailySpent, dailyCap, totalTokens, requestsToday }: CostMonitorProps) {
  const percentUsed = (dailySpent / dailyCap) * 100;
  const isNearLimit = percentUsed >= 80;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-6 border border-border shadow-[var(--elevation-sm)] bg-card">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-chart-4/10 backdrop-blur-sm shadow-[var(--elevation-sm)]">
            <DollarIcon className="w-5 h-5 text-chart-4" />
          </div>
          <h3>Daily Cost Monitor</h3>
        </div>
        <div className="flex items-center gap-1.5 px-4 py-2 bg-chart-4/10 rounded-xl backdrop-blur-sm shadow-[var(--elevation-sm)]">
          <span className="text-2xl font-semibold text-chart-4">${dailySpent.toFixed(2)}</span>
          <span className="text-sm opacity-70">/ ${dailyCap.toFixed(2)}</span>
        </div>
      </div>

      <div className="mb-5">
        <div className="flex items-center justify-between mb-2 text-xs">
          <span className="opacity-70">Budget Usage</span>
          <motion.span 
            className={`font-medium ${isNearLimit ? 'text-destructive' : 'text-chart-4'}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            {percentUsed.toFixed(0)}%
          </motion.span>
        </div>
        <div className="relative h-3 w-full overflow-hidden rounded-full bg-primary/10">
          <motion.div 
            className={`h-full ${isNearLimit ? 'bg-destructive' : 'bg-chart-4'}`}
            initial={{ width: 0 }}
            animate={{ width: `${percentUsed}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </div>
      </div>

      {isNearLimit && (
        <Alert className="mb-4 border border-destructive bg-destructive/10" variant="destructive">
          <AlertIcon className="h-4 w-4" />
          <AlertDescription>
            You've used {percentUsed.toFixed(0)}% of your daily API budget. Service may pause when limit is reached.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-2 gap-4">
        <motion.div 
          className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm border border-border hover:bg-primary/10 transition-colors cursor-pointer"
          whileHover={{ scale: 1.02, y: -2 }}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <p className="text-xs opacity-70 mb-2">Total Tokens</p>
          <p className="text-xl font-semibold text-foreground">{totalTokens.toLocaleString()}</p>
        </motion.div>
        <motion.div 
          className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm border border-border hover:bg-primary/10 transition-colors cursor-pointer"
          whileHover={{ scale: 1.02, y: -2 }}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <p className="text-xs opacity-70 mb-2">Requests Today</p>
          <p className="text-xl font-semibold text-foreground">{requestsToday}</p>
        </motion.div>
      </div>
      </Card>
    </motion.div>
  );
}
