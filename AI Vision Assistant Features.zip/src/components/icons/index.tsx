import svgPaths from "../../imports/svg-kket9nlqkn";

interface IconProps {
  className?: string;
  style?: React.CSSProperties;
}

// Eye/Vision - using Info Circle (represents observation/monitoring)
export function EyeIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <g opacity="0.5">
        <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" />
      </g>
      <path d="M12 17V11" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="1" cy="1" fill="currentColor" r="1" transform="matrix(1 0 0 -1 11 9)" />
    </svg>
  );
}

// Camera - using Box (represents recording/capture)
export function CameraIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p1572b480} stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d={svgPaths.pb41c280} opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Settings - using Settings Fine Tuning
export function SettingsIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
      <path d={svgPaths.p39ebcd00} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p1ca8a800} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p4621d40} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p792bc00} stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Refresh - using Infinity/loop symbol
export function RefreshIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M20.5 6H3.49992" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d={svgPaths.p1ea2de00} stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d={svgPaths.p197779c0} opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Shield - using Shield/Star Ring
export function ShieldIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p15a9f480} opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p1f446ee0} stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d={svgPaths.p2ad57700} stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d={svgPaths.p1be79c00} stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Chart/Analytics - using Posts Carousel
export function ChartIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p2c258380} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p9468e00} opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d={svgPaths.p6e439db} opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Filter - using Filter icon
export function FilterIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p1d660888} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p184cca00} opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Location/Pin - using Pin
export function LocationIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p74a09f0} fill="currentColor" />
      <path d={svgPaths.pe25f280} fill="currentColor" opacity="0.5" />
    </svg>
  );
}

// Activity/Pulse - using Bolt
export function ActivityIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p3ef3f600} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p3a0f1500} opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Dollar/Money - using Crown (represents value/premium)
export function DollarIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p26249e80} fill="currentColor" />
      <path d="M5 17.5H19" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Message/Chat - using Home (represents communication hub)
export function MessageIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p223ba100} opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M15 18H9" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Microphone - using Fuel (represents input/energy)
export function MicIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p3c992800} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p2184fb00} stroke="currentColor" strokeWidth="1.5" />
      <path d="M15 11L16 10" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M9 11L8 10" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Mic Off - using Fuel (different state)
export function MicOffIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p3c992800} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.p2184fb00} stroke="currentColor" strokeWidth="1.5" />
      <path d="M15 17L16 18" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M9 17L8 18" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Play - using Bolt Circle
export function PlayIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d={svgPaths.p1a0a8300} stroke="currentColor" strokeWidth="1.5" />
      <path d={svgPaths.pd01100} opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Pause - using Menu Dots
export function PauseIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <circle cx="5" cy="12" r="2" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="12" cy="12" opacity="0.5" r="2" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="19" cy="12" r="2" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Wifi Off - using Forbidden Circle
export function WifiOffIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M18.5 5.5L5.50002 18.4998" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Alert/Warning - using Danger Circle
export function AlertIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <circle cx="12" cy="12" opacity="0.5" r="10" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 7V13" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="12" cy="16" fill="currentColor" r="1" />
    </svg>
  );
}

// Volume/Speaker - using Volume
export function VolumeIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M14 6V18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M7 14V10H4V14H7Z" stroke="currentColor" strokeWidth="1.5" />
      <path d="M7 10L14 6V18L7 14" opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M17 8C17.5 8.5 18 9.5 18 12C18 14.5 17.5 15.5 17 16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M20 6C21 7 22 9 22 12C22 15 21 17 20 18" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Clock/Time - using Clock
export function ClockIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 8V12L14.5 14.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}

// Moon - using Moon/Night mode icon
export function MoonIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M21.0672 11.8568L20.4253 11.469L21.0672 11.8568ZM12.1432 2.93276L11.7553 2.29085V2.29085L12.1432 2.93276ZM7.37554 20.013C7.017 19.8056 6.5582 19.9281 6.3508 20.2866C6.14339 20.6452 6.26591 21.104 6.62446 21.3114L7.37554 20.013ZM2.68862 17.3755C2.89602 17.7341 3.35482 17.8566 3.71337 17.6492C4.07191 17.4418 4.19443 16.983 3.98703 16.6245L2.68862 17.3755ZM21.25 12C21.25 17.1086 17.1086 21.25 12 21.25V22.75C17.9371 22.75 22.75 17.9371 22.75 12H21.25ZM12 21.25C6.89137 21.25 2.75 17.1086 2.75 12H1.25C1.25 17.9371 6.06294 22.75 12 22.75V21.25ZM2.75 12C2.75 11.6727 2.77018 11.3502 2.80923 11.0335L1.31105 10.8625C1.2642 11.2393 1.25 11.6252 1.25 12H2.75ZM21.7092 12.2446C21.7683 11.8283 21.4952 11.4422 21.0789 11.3831C20.6626 11.324 20.2765 11.5971 20.2174 12.0134L21.7092 12.2446ZM11.7553 2.29085C12.0734 2.09984 12.185 1.69265 11.994 1.37457C11.803 1.05649 11.3958 0.944892 11.0777 1.13589L11.7553 2.29085ZM21.7092 11.469C21.1364 8.45941 18.5406 6.13636 15.5 5.75V7.25C17.7594 7.55364 19.6136 9.23052 20.0674 11.469L21.7092 11.469ZM15.5 5.75C12.4594 6.13636 9.86357 8.45941 9.29078 11.469L10.8326 11.469C11.2864 9.23052 13.1406 7.55364 15.5 7.25V5.75ZM9.29078 11.469C9.04857 12.978 8.2984 14.2558 7.37554 20.013L6.62446 21.3114C7.54732 15.5542 8.29749 14.2764 8.539 12.7674L9.29078 11.469ZM2.68862 17.3755C2.39598 16.9281 2.08134 16.5049 1.7536 16.1035L0.746399 16.8965C1.06866 17.2935 1.38402 17.7219 1.67666 18.1693L2.68862 17.3755ZM1.7536 16.1035C1.41309 15.6914 1.05978 15.3045 0.695413 14.9465L-0.0955871 15.9537C0.274783 16.3182 0.633091 16.7104 0.976399 17.1285L1.7536 16.1035ZM0.695413 14.9465C0.321653 14.5785 -0.0463988 14.2234 -0.404113 13.8731L-1.3959 14.6269C-1.04119 14.9745 -0.653847 15.3346 -0.279587 15.7065L0.695413 14.9465ZM-0.404113 13.8731C-0.764827 13.5204 -1.11837 13.1721 -1.46369 12.8265L-2.45631 13.5807C-2.11163 13.9263 -1.75173 14.2796 -1.3959 14.6269L-0.404113 13.8731ZM-1.46369 12.8265C-1.81199 12.4782 -2.15063 12.1332 -2.47943 11.7916L-3.47057 12.5458C-3.13937 12.8894 -2.79801 13.2368 -2.45631 13.5807L-1.46369 12.8265ZM-2.47943 11.7916C-2.81024 11.4486 -3.13163 11.1088 -3.44341 10.7722L-4.43659 11.5264C-4.12163 11.8656 -3.79704 12.2086 -3.47057 12.5458L-2.47943 11.7916ZM-3.44341 10.7722C-3.75819 10.4338 -4.06364 10.0976 -4.35959 9.76312L-5.35041 10.5171C-5.05136 10.8548 -4.74181 11.1942 -4.43659 11.5264L-3.44341 10.7722ZM-4.35959 9.76312C-4.65864 9.4268 -4.94864 9.09212 -5.22949 8.7591L-6.22051 9.5129C-5.93636 9.84896 -5.64336 10.1868 -5.35041 10.5171L-4.35959 9.76312ZM-5.22949 8.7591C-5.51334 8.4242 -5.78864 8.09096 -6.05529 7.75936L-7.04471 8.51312C-6.77536 8.84776 -6.49666 9.18404 -6.22051 9.5129L-5.22949 8.7591ZM-6.05529 7.75936C-6.32494 7.4258 -6.58664 7.09376 -6.83989 6.76324L-7.82611 7.51676C-7.56936 7.85124 -7.30406 8.18724 -7.04471 8.51312L-6.05529 7.75936ZM-6.83989 6.76324C-7.09614 6.4308 -7.34464 6.09988 -7.58509 5.77048L-8.56891 6.52352C-8.32536 6.85612 -8.07386 7.19024 -7.82611 7.51676L-6.83989 6.76324ZM-7.58509 5.77048C-7.82854 5.43808 -8.06464 5.10716 -8.29299 4.77772L-9.27501 5.53028C-9.04336 5.86292 -8.80446 6.19704 -8.56891 6.52352L-7.58509 5.77048ZM-8.29299 4.77772C-8.52434 4.4454 -8.74864 4.11452 -8.96539 3.78508L-9.94661 4.53792C-9.72636 4.87052 -9.49866 5.20468 -9.27501 5.53028L-8.29299 4.77772ZM-8.96539 3.78508C-9.18514 3.4528 -9.39764 3.12192 -9.60239 2.79244L-10.5816 3.54556C-10.3741 3.87812 -10.1589 4.21216 -9.94661 4.53792L-8.96539 3.78508ZM-9.60239 2.79244C-9.81014 2.46 -10.0105 2.12896 -10.2033 1.79932L-11.1807 2.55268C-10.9852 2.88532 -10.7822 3.21936 -10.5816 3.54556L-9.60239 2.79244ZM-10.2033 1.79932C-10.3991 1.4668 -10.5877 1.13568 -10.7691 0.805964L-11.7441 1.55936C-11.5599 1.89216 -11.3687 2.22624 -11.1807 2.55268L-10.2033 1.79932ZM-10.7691 0.805964C-10.9535 0.472764 -11.1307 0.140964 -11.3007 -0.189836L-12.2737 0.563564C-12.1009 0.897564 -11.9211 1.23236 -11.7441 1.55936L-10.7691 0.805964Z" fill="currentColor" opacity="0.5" />
    </svg>
  );
}

// Sun - using Sun/Day mode icon
export function SunIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 2V4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M12 20V22" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M4 12H2" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M22 12H20" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M19.0784 4.92157L17.6642 6.33578" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M6.33574 17.6642L4.92153 19.0784" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M19.0784 19.0784L17.6642 17.6642" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M6.33574 6.33578L4.92153 4.92157" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Map/Navigation - using Map Point
export function MapIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M9 4L4 6V18L9 16M9 4L15 2M9 4V16M15 2L20 4V16L15 18M15 2V14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
      <path d="M9 16L15 18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" opacity="0.5" />
    </svg>
  );
}

// Trending Up - using Arrow Up
export function TrendingUpIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M19 15L12 9L5 15" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
      <path d="M19 9V15H13" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}

// Fire - using Flame/Fire icon
export function FireIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M12 3C12 3 8.5 6 8.5 10C8.5 12.2091 10.2909 14 12.5 14C14.7091 14 16.5 12.2091 16.5 10C16.5 8 15 6 15 6C15 6 16 7 16 9C16 10.1046 15.1046 11 14 11C12.8954 11 12 10.1046 12 9V3Z" fill="currentColor" />
      <path d="M12.5 14C10.2909 14 8.5 12.2091 8.5 10C8.5 6 12 3 12 3V9C12 10.1046 12.8954 11 14 11C15.1046 11 16 10.1046 16 9C16 7 15 6 15 6C15 6 16.5 8 16.5 10C16.5 12.2091 14.7091 14 12.5 14Z" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
      <path d="M8.5 15C6 16 4 18 4 20.5C4 21.8807 5.11929 23 6.5 23H18.5C19.8807 23 21 21.8807 21 20.5C21 18 19 16 16.5 15" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
    </svg>
  );
}

// Productivity - using Briefcase icon
export function ProductivityIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <rect width="18" height="12" x="3" y="8" stroke="currentColor" strokeWidth="1.5" rx="2" />
      <path d="M7 8V6C7 4.89543 7.89543 4 9 4H15C16.1046 4 17 4.89543 17 6V8" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <path d="M3 13H21" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="12" cy="13" r="1.5" fill="currentColor" opacity="0.5" />
    </svg>
  );
}

// Entertainment - using Game Controller icon
export function EntertainmentIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M6 14H10M8 12V16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="16" cy="13" r="1" fill="currentColor" />
      <circle cx="18" cy="15" r="1" fill="currentColor" />
      <path d="M3.5 11C3.5 9.89543 4.39543 9 5.5 9H18.5C19.6046 9 20.5 9.89543 20.5 11V13C20.5 15.2091 18.7091 17 16.5 17H15C14.4477 17 14 17.4477 14 18C14 18.5523 13.5523 19 13 19H11C10.4477 19 10 18.5523 10 18C10 17.4477 9.55228 17 9 17H7.5C5.29086 17 3.5 15.2091 3.5 13V11Z" opacity="0.5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

// Health - using Heart Pulse icon
export function HealthIcon({ className = "w-6 h-6", style }: IconProps) {
  return (
    <svg className={className} style={style} fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
      <path d="M20.84 4.61C19.5 3.37 17.76 2.75 16 2.75C14.24 2.75 12.5 3.37 11.16 4.61L12 5.47L12.84 4.61C13.88 3.67 15.2 3.25 16.52 3.25C17.84 3.25 19.16 3.67 20.2 4.61C22.28 6.49 22.28 9.51 20.2 11.39L12 19.59L3.8 11.39C1.72 9.51 1.72 6.49 3.8 4.61C4.84 3.67 6.16 3.25 7.48 3.25C8.8 3.25 10.12 3.67 11.16 4.61" opacity="0.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
      <path d="M6 12H8L9.5 10L11 14L12.5 12H15" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}
