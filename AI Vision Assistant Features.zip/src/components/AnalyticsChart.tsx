import { Card } from "./ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Area, AreaChart } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import type { ActivityCategory } from "./ActivityCard";
import { motion } from "motion/react";
import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface AnalyticsData {
  day: string;
  Productivity: number;
  Health: number;
  Entertainment: number;
  Social: number;
  Other: number;
}

interface DailyAnalyticsData {
  time: string;
  Productivity: number;
  Health: number;
  Entertainment: number;
  Social: number;
  Other: number;
}

interface AnalyticsChartProps {
  data: AnalyticsData[];
  dailyData: DailyAnalyticsData[];
}

export function AnalyticsChart({ data, dailyData }: AnalyticsChartProps) {
  const [isAnimated, setIsAnimated] = useState(false);
  const [viewMode, setViewMode] = useState<"hours" | "percentage">("hours");
  
  // Calculate totals for each category across the week
  const categoryTotals = data.reduce((acc, day) => {
    acc.Productivity += day.Productivity;
    acc.Health += day.Health;
    acc.Entertainment += day.Entertainment;
    acc.Social += day.Social;
    acc.Other += day.Other;
    return acc;
  }, { Productivity: 0, Health: 0, Entertainment: 0, Social: 0, Other: 0 });

  const totalMinutes = Object.values(categoryTotals).reduce((sum, val) => sum + val, 0);
  const totalHours = (totalMinutes / 60).toFixed(1);

  // Pie chart data
  const pieData = [
    { name: "Productivity", value: categoryTotals.Productivity, color: "var(--chart-1)" },
    { name: "Health", value: categoryTotals.Health, color: "var(--chart-4)" },
    { name: "Entertainment", value: categoryTotals.Entertainment, color: "var(--chart-3)" },
    { name: "Social", value: categoryTotals.Social, color: "var(--chart-2)" },
    { name: "Other", value: categoryTotals.Other, color: "var(--chart-5)" },
  ].filter(item => item.value > 0);

  // Transform data based on view mode
  const transformedPieData = pieData.map(item => ({
    ...item,
    displayValue: viewMode === "hours" 
      ? (item.value / 60).toFixed(1)
      : ((item.value / totalMinutes) * 100).toFixed(1)
  }));

  // Peak activity hours from daily data
  const peakHours = dailyData.map((slot) => {
    const total = slot.Productivity + slot.Health + slot.Entertainment + slot.Social + slot.Other;
    return {
      time: slot.time,
      total: total,
      hours: (total / 60).toFixed(1)
    };
  }).sort((a, b) => b.total - a.total).slice(0, 6); // Top 6 most active hours

  // Category trends over the week
  const categoryTrends = [
    { name: "Productivity", data: data.map(d => ({ day: d.day, value: d.Productivity })), color: "var(--chart-1)" },
    { name: "Health", data: data.map(d => ({ day: d.day, value: d.Health })), color: "var(--chart-4)" },
    { name: "Entertainment", data: data.map(d => ({ day: d.day, value: d.Entertainment })), color: "var(--chart-3)" },
    { name: "Social", data: data.map(d => ({ day: d.day, value: d.Social })), color: "var(--chart-2)" },
    { name: "Other", data: data.map(d => ({ day: d.day, value: d.Other })), color: "var(--chart-5)" },
  ];

  const renderCustomLabel = (entry: any) => {
    const percentage = ((entry.value / totalMinutes) * 100).toFixed(0);
    return `${percentage}%`;
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      onAnimationComplete={() => setIsAnimated(true)}
    >
      <Card className="p-6 border border-border shadow-[var(--elevation-sm)]">
        <motion.div 
          className="mb-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="mb-2">Activity Analytics</h3>
          <p className="text-sm opacity-70">
            Apple Screen Time-style breakdown by category
          </p>
        </motion.div>

      <Tabs defaultValue="weekly" className="space-y-4">
        <TabsList className="p-1 bg-card backdrop-blur-sm border border-border inline-flex gap-1 rounded-xl">
          <TabsTrigger value="weekly" className="rounded-lg px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
            Weekly
          </TabsTrigger>
          <TabsTrigger value="daily" className="rounded-lg px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
            Today
          </TabsTrigger>
          <TabsTrigger value="trends" className="rounded-lg px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
            Trends
          </TabsTrigger>
        </TabsList>

        <TabsContent value="weekly" className="space-y-4 m-0">
          <motion.div 
            className="p-4 rounded-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                <XAxis 
                  dataKey="day" 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                  label={{ value: 'Minutes', angle: -90, position: 'insideLeft', fontSize: 12, fill: 'var(--foreground)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    padding: '12px',
                    boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.25)',
                    color: 'var(--card-foreground)'
                  }}
                  cursor={{ fill: 'var(--primary)', opacity: 0.1 }}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '20px' }}
                  iconType="circle"
                />
                <Bar dataKey="Productivity" stackId="a" fill="var(--chart-1)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={0} />
                <Bar dataKey="Health" stackId="a" fill="var(--chart-4)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={100} />
                <Bar dataKey="Entertainment" stackId="a" fill="var(--chart-3)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={200} />
                <Bar dataKey="Social" stackId="a" fill="var(--chart-2)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={300} />
                <Bar dataKey="Other" stackId="a" fill="var(--chart-5)" radius={[3, 3, 0, 0]} animationDuration={1000} animationBegin={400} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </TabsContent>

        <TabsContent value="daily" className="space-y-4 m-0">
          <motion.div 
            className="p-4 rounded-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                  label={{ value: 'Minutes', angle: -90, position: 'insideLeft', fontSize: 12, fill: 'var(--foreground)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    padding: '12px',
                    boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.25)',
                    color: 'var(--card-foreground)'
                  }}
                  cursor={{ fill: 'var(--primary)', opacity: 0.1 }}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '20px' }}
                  iconType="circle"
                />
                <Bar dataKey="Productivity" stackId="a" fill="var(--chart-1)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={0} />
                <Bar dataKey="Health" stackId="a" fill="var(--chart-4)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={100} />
                <Bar dataKey="Entertainment" stackId="a" fill="var(--chart-3)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={200} />
                <Bar dataKey="Social" stackId="a" fill="var(--chart-2)" radius={[0, 0, 0, 0]} animationDuration={1000} animationBegin={300} />
                <Bar dataKey="Other" stackId="a" fill="var(--chart-5)" radius={[3, 3, 0, 0]} animationDuration={1000} animationBegin={400} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6 m-0">
          {/* View Mode Toggle */}
          <motion.div 
            className="flex items-center justify-between gap-4 flex-wrap"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div>
              <h4 className="mb-1">Category Distribution</h4>
              <p className="text-sm opacity-60">
                {totalHours}h total screen time this week
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant={viewMode === "hours" ? "default" : "outline"}
                onClick={() => setViewMode("hours")}
                className="rounded-xl"
                size="sm"
              >
                Hours
              </Button>
              <Button
                variant={viewMode === "percentage" ? "default" : "outline"}
                onClick={() => setViewMode("percentage")}
                className="rounded-xl"
                size="sm"
              >
                % of Day
              </Button>
            </div>
          </motion.div>

          {/* Pie Chart and Stats Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pie Chart */}
            <motion.div
              className="p-4 rounded-xl bg-primary/5 border border-border"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              <h4 className="mb-3">Weekly Breakdown</h4>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={transformedPieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={renderCustomLabel}
                    outerRadius={85}
                    fill="#8884d8"
                    dataKey="value"
                    animationDuration={1000}
                  >
                    {transformedPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '12px',
                      padding: '12px',
                      boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.25)',
                      color: 'var(--card-foreground)'
                    }}
                    formatter={(value: any) => {
                      if (viewMode === "hours") {
                        return `${(value / 60).toFixed(1)}h`;
                      } else {
                        return `${((value / totalMinutes) * 100).toFixed(1)}%`;
                      }
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Category Stats */}
            <motion.div
              className="space-y-2.5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              {transformedPieData.map((category, index) => (
                <motion.div
                  key={category.name}
                  className="p-3.5 rounded-xl bg-card border border-border hover:border-primary/50 transition-all"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ x: 4 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: category.color }}
                      />
                      <span className="text-sm">{category.name}</span>
                    </div>
                    <Badge 
                      variant="outline" 
                      className="rounded-full px-2.5 py-0.5"
                      style={{ 
                        backgroundColor: `${category.color}15`,
                        borderColor: `${category.color}40`
                      }}
                    >
                      {category.displayValue}{viewMode === "hours" ? "h" : "%"}
                    </Badge>
                  </div>
                  <div className="w-full bg-border/30 rounded-full h-2 overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: category.color }}
                      initial={{ width: 0 }}
                      animate={{ 
                        width: `${((category.value / totalMinutes) * 100)}%` 
                      }}
                      transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                    />
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Most Active Hours */}
          <motion.div
            className="p-4 rounded-xl bg-primary/5 border border-border"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <h4 className="mb-4">Peak Activity Hours</h4>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={peakHours} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                <XAxis 
                  type="number"
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                  label={{ value: 'Minutes', position: 'insideBottom', offset: -5, fontSize: 12, fill: 'var(--foreground)' }}
                />
                <YAxis 
                  type="category"
                  dataKey="time" 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                  width={60}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    padding: '12px',
                    boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.25)',
                    color: 'var(--card-foreground)'
                  }}
                  formatter={(value: any) => [`${(value / 60).toFixed(1)}h`, 'Activity']}
                />
                <Bar 
                  dataKey="total" 
                  fill="var(--primary)" 
                  radius={[0, 8, 8, 0]}
                  animationDuration={1000}
                />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Category Comparison Line Chart */}
          <motion.div
            className="p-4 rounded-xl bg-primary/5 border border-border"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <h4 className="mb-4">Category Trends Comparison</h4>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                <XAxis 
                  dataKey="day" 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: 'var(--foreground)' }}
                  stroke="var(--border)"
                  tickLine={false}
                  label={{ value: 'Minutes', angle: -90, position: 'insideLeft', fontSize: 12, fill: 'var(--foreground)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    padding: '12px',
                    boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.25)',
                    color: 'var(--card-foreground)'
                  }}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '20px' }}
                  iconType="circle"
                />
                <Line 
                  type="monotone" 
                  dataKey="Productivity" 
                  stroke="var(--chart-1)" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  animationDuration={1000}
                />
                <Line 
                  type="monotone" 
                  dataKey="Health" 
                  stroke="var(--chart-4)" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  animationDuration={1000}
                  animationBegin={100}
                />
                <Line 
                  type="monotone" 
                  dataKey="Entertainment" 
                  stroke="var(--chart-3)" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  animationDuration={1000}
                  animationBegin={200}
                />
                <Line 
                  type="monotone" 
                  dataKey="Social" 
                  stroke="var(--chart-2)" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  animationDuration={1000}
                  animationBegin={300}
                />
                <Line 
                  type="monotone" 
                  dataKey="Other" 
                  stroke="var(--chart-5)" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  animationDuration={1000}
                  animationBegin={400}
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>
        </TabsContent>
      </Tabs>
      </Card>
    </motion.div>
  );
}
