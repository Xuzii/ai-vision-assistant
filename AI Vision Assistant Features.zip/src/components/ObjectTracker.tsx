import { Card } from "./ui/card";
import { LocationIcon, ClockIcon } from "./icons";
import { motion } from "motion/react";

interface TrackedObject {
  id: string;
  name: string;
  category: string;
  location: string;
  lastSeen: string;
  confidence: number;
  status: "present" | "missing";
}

interface ObjectTrackerProps {
  objects: TrackedObject[];
}

const categoryIcons: { [key: string]: string } = {
  Electronics: "💻",
  Furniture: "🪑",
  Kitchen: "🍳",
  Personal: "👜",
  Appliances: "📺",
  Other: "📦",
};

const categoryColors: { [key: string]: string } = {
  Electronics: "chart-1",
  Furniture: "chart-2",
  Kitchen: "chart-3",
  Personal: "chart-4",
  Appliances: "chart-5",
  Other: "primary",
};

export function ObjectTracker({ objects }: ObjectTrackerProps) {
  return (
    <div className="space-y-4">
      <motion.div 
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div>
          <h2>Tracked Objects</h2>
          <p className="text-sm opacity-70 mt-1">Important household items monitored by AI vision</p>
        </div>
        <motion.div 
          className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-xl shadow-[var(--elevation-sm)]"
          whileHover={{ scale: 1.05 }}
        >
          <span className="text-sm opacity-70">Total:</span>
          <motion.span 
            className="font-semibold text-lg"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
          >
            {objects.length}
          </motion.span>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {objects.map((obj, index) => (
          <motion.div
            key={obj.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05, duration: 0.4 }}
            whileHover={{ y: -4 }}
          >
            <Card className="p-4 border border-border shadow-[var(--elevation-sm)] bg-card hover:border-primary/50 hover:shadow-lg transition-all">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{categoryIcons[obj.category] || "📦"}</span>
                <div>
                  <h4 className="mb-0">{obj.name}</h4>
                  <span className="text-xs opacity-60">{obj.category}</span>
                </div>
              </div>
              <div className={`px-2 py-1 rounded-lg text-xs ${
                obj.status === "present" 
                  ? "bg-chart-4/10 text-chart-4 border border-chart-4/20" 
                  : "bg-destructive/10 text-destructive border border-destructive/20"
              }`}>
                {obj.status === "present" ? "Present" : "Missing"}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <LocationIcon className="w-4 h-4 opacity-60" />
                <span className="opacity-70">{obj.location}</span>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <ClockIcon className="w-4 h-4 opacity-60" />
                <span className="opacity-70">Last seen: {obj.lastSeen}</span>
              </div>

              <div className="pt-2 border-t border-border">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs opacity-60">Confidence</span>
                  <span className="text-xs font-medium">{obj.confidence}%</span>
                </div>
                <div className="relative h-2 w-full overflow-hidden rounded-full bg-primary/10">
                  <motion.div 
                    className="h-full bg-chart-4"
                    initial={{ width: 0 }}
                    animate={{ width: `${obj.confidence}%` }}
                    transition={{ duration: 1, delay: index * 0.05 + 0.2, ease: "easeOut" }}
                  />
                </div>
              </div>
            </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
