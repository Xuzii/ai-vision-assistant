import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import { TrendingUpIcon, FireIcon, ClockIcon, ProductivityIcon, EntertainmentIcon, HealthIcon } from "./icons";

interface TodayOverviewProps {
  deskTime: string;
  uniqueActivities: number;
  percentChange: number;
  streak: number;
  categoryBreakdown: {
    productivity: number;
    entertainment: number;
    health: number;
  };
}

export function TodayOverview({
  deskTime,
  uniqueActivities,
  percentChange,
  streak,
  categoryBreakdown,
}: TodayOverviewProps) {
  const isPositiveChange = percentChange >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-7 md:p-6 border border-border shadow-[var(--elevation-sm)] bg-card">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 md:gap-6">
          {/* Left Section - Summary */}
          <div className="flex-1">
            <div className="flex items-center justify-center lg:justify-start gap-2 mb-4">
              <motion.div
                className="p-2 rounded-xl bg-primary/10 backdrop-blur-sm"
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <ClockIcon className="w-5 h-5 text-primary" />
              </motion.div>
              <h3 className="mb-0">Today Overview</h3>
            </div>

            <div className="flex flex-col md:flex-row md:flex-wrap items-center justify-center lg:justify-start gap-3 md:gap-2 mb-5 text-center lg:text-left">
              <p className="opacity-80 mb-0">
                You've been at your desk for{" "}
                <span className="text-primary">{deskTime}</span>
              </p>
              <span className="opacity-40 hidden md:inline">·</span>
              <p className="opacity-80 mb-0">
                {uniqueActivities} unique activities detected
              </p>
              <span className="opacity-40 hidden md:inline">·</span>
              <motion.div
                className="flex items-center gap-1.5"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
              >
                <TrendingUpIcon
                  className={`w-4 h-4 ${
                    isPositiveChange ? "text-chart-4" : "text-destructive"
                  }`}
                />
                <p
                  className={`mb-0 ${
                    isPositiveChange ? "text-chart-4" : "text-destructive"
                  }`}
                >
                  {Math.abs(percentChange)}% {isPositiveChange ? "increase" : "decrease"} from
                  yesterday
                </p>
              </motion.div>
            </div>

            {/* Category Chips */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 md:gap-2">
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
              >
                <Badge
                  variant="outline"
                  className="px-3 py-1.5 rounded-full bg-chart-1/10 border-chart-1/20 text-chart-1 hover:bg-chart-1/20 transition-colors flex items-center gap-1.5"
                >
                  <ProductivityIcon className="w-4 h-4" />
                  Productivity · {categoryBreakdown.productivity}%
                </Badge>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Badge
                  variant="outline"
                  className="px-3 py-1.5 rounded-full bg-chart-3/10 border-chart-3/20 text-chart-3 hover:bg-chart-3/20 transition-colors flex items-center gap-1.5"
                >
                  <EntertainmentIcon className="w-4 h-4" />
                  Entertainment · {categoryBreakdown.entertainment}%
                </Badge>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Badge
                  variant="outline"
                  className="px-3 py-1.5 rounded-full bg-chart-4/10 border-chart-4/20 text-chart-4 hover:bg-chart-4/20 transition-colors flex items-center gap-1.5"
                >
                  <HealthIcon className="w-4 h-4" />
                  Health · {categoryBreakdown.health}%
                </Badge>
              </motion.div>
            </div>
          </div>

          {/* Right Section - Streak Indicator */}
          <motion.div
            className="flex lg:flex-col items-center justify-center gap-3 p-5 md:p-4 rounded-2xl bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/20 w-full lg:w-auto max-w-xs lg:max-w-none mx-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6, type: "spring", stiffness: 200 }}
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              className="relative"
              animate={{
                rotate: [0, -10, 10, -10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3,
              }}
            >
              <div className="absolute inset-0 bg-accent/20 rounded-full blur-xl" />
              <FireIcon className="w-10 h-10 text-accent relative" />
            </motion.div>
            <div className="text-center">
              <p className="opacity-60 mb-0 text-sm">Streak</p>
              <motion.p
                className="mb-0 text-accent"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.8, type: "spring", stiffness: 300 }}
              >
                {streak} days
              </motion.p>
            </div>
          </motion.div>
        </div>
      </Card>
    </motion.div>
  );
}
