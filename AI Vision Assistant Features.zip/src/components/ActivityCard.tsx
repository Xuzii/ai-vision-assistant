import { LocationIcon, ActivityIcon, DollarIcon, CameraIcon } from "./icons";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export type ActivityCategory = "Productivity" | "Health" | "Entertainment" | "Social" | "Other";

interface ActivityCardProps {
  person: string;
  location: string;
  activity: string;
  category: ActivityCategory;
  timestamp: string;
  tokens: number;
  cost: number;
  thumbnail?: string;
}

const categoryColors: Record<ActivityCategory, string> = {
  Productivity: "bg-chart-1",
  Health: "bg-chart-4",
  Entertainment: "bg-chart-3",
  Social: "bg-chart-2",
  Other: "bg-chart-5"
};

const categoryIcons: Record<ActivityCategory, string> = {
  Productivity: "💼",
  Health: "💪",
  Entertainment: "🎮",
  Social: "👥",
  Other: "📌"
};

export function ActivityCard({ 
  person, 
  location, 
  activity, 
  category, 
  timestamp, 
  tokens,
  cost,
  thumbnail 
}: ActivityCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      whileHover={{ scale: 1.02, y: -4 }}
    >
      <Card className="p-5 hover:shadow-2xl transition-all duration-300 border border-border shadow-[var(--elevation-sm)] group cursor-pointer overflow-hidden relative">
        {/* Gradient overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
        
        <div className="relative z-10">
          {/* Thumbnail Section */}
          {thumbnail && (
            <motion.div 
              className="mb-4 -mx-5 -mt-5 overflow-hidden"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              transition={{ duration: 0.3 }}
            >
              <div className="relative h-32 bg-primary/5 group-hover:scale-105 transition-transform duration-300">
                <ImageWithFallback
                  src={thumbnail}
                  alt={`${person} - ${activity}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card/90 via-card/40 to-transparent"></div>
                <motion.div 
                  className="absolute top-2 right-2 p-1.5 bg-card/80 backdrop-blur-sm rounded-lg border border-border"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                >
                  <CameraIcon className="w-3 h-3 text-primary" />
                </motion.div>
              </div>
            </motion.div>
          )}
          
          <div className={`flex items-start justify-between gap-3 ${thumbnail ? 'mb-3' : 'mb-4'}`}>
            <div className="flex-1 min-w-0">
              <motion.h4 
                className="mb-2"
                whileHover={{ x: 4 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {person}
              </motion.h4>
              <div className="flex items-center gap-2 text-sm">
                <motion.span 
                  className="flex items-center gap-1 px-2 py-0.5 bg-primary/10 rounded-full text-foreground"
                  whileHover={{ scale: 1.05 }}
                >
                  <LocationIcon className="w-3 h-3" />
                  <span className="text-xs">{location}</span>
                </motion.span>
              </div>
            </div>
            <div className="flex flex-col items-end gap-3">
              <motion.div
                whileHover={{ rotate: 5, scale: 1.1 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Badge className={`${categoryColors[category]} border-0 text-white shadow-[var(--elevation-sm)] px-3 py-1 rounded-full`}>
                  <span className="mr-1.5">{categoryIcons[category]}</span>
                  {category}
                </Badge>
              </motion.div>
              <span className="text-xs opacity-60 whitespace-nowrap">{timestamp}</span>
            </div>
          </div>
          
          <motion.div 
            className="flex items-start gap-3 mb-4 p-3 bg-primary/5 rounded-xl"
            whileHover={{ backgroundColor: "rgba(var(--primary-rgb, 9, 44, 76), 0.08)" }}
          >
            <ActivityIcon className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />
            <p className="text-sm leading-relaxed text-foreground">{activity}</p>
          </motion.div>

          <div className="flex items-center justify-between text-xs pt-3 border-t border-dashed border-border">
            <span className="flex items-center gap-1.5 text-foreground opacity-70">
              <motion.span 
                className="w-1.5 h-1.5 bg-primary rounded-full"
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              ></motion.span>
              {tokens.toLocaleString()} tokens
            </span>
            <motion.span 
              className="flex items-center gap-1 font-medium"
              whileHover={{ scale: 1.1 }}
            >
              <DollarIcon className="w-3 h-3 text-chart-4" />
              <span className="text-chart-4">{cost.toFixed(4)}</span>
            </motion.span>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
