import { ActivityIcon, LocationIcon } from "./icons";
import type { ActivityCategory } from "./ActivityCard";

interface CameraActivityBarProps {
  person?: string;
  activity?: string;
  category?: ActivityCategory;
  timestamp?: string;
  tokens?: number;
}

const categoryColors = {
  Productivity: "bg-chart-1",
  Health: "bg-chart-4",
  Entertainment: "bg-chart-3",
  Social: "bg-chart-2",
  Other: "bg-chart-5",
};

const categoryIcons = {
  Productivity: "💼",
  Health: "💪",
  Entertainment: "🎮",
  Social: "👥",
  Other: "📌",
};

export function CameraActivityBar({ person, activity, category, timestamp, tokens }: CameraActivityBarProps) {
  if (!person || !activity) {
    return (
      <div className="p-3 bg-primary/5 border border-border rounded-xl">
        <p className="text-sm opacity-50 text-center">No recent activity</p>
      </div>
    );
  }

  return (
    <div className="p-2 bg-card rounded-xl transition-all">
      <div className="flex items-center gap-3">
        {/* Category indicator */}
        <div className={`flex-shrink-0 w-1 h-full ${categoryColors[category!]} rounded-full`}></div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <div className="flex items-center gap-2">
              <span className="text-sm">{categoryIcons[category!]}</span>
              <span className="text-sm font-medium">{person}</span>
            </div>
            <span className="text-xs opacity-60 whitespace-nowrap">{timestamp}</span>
          </div>
          
          <p className="text-sm opacity-80 line-clamp-1 mb-1.5">{activity}</p>
          
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 text-xs opacity-60">
              <span className="w-1 h-1 bg-primary rounded-full"></span>
              {tokens?.toLocaleString()} tokens
            </span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${categoryColors[category!]}/10 border border-${categoryColors[category!]}/20`}>
              {category}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
