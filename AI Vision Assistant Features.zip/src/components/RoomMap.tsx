import { Card } from "./ui/card";

interface RoomMapProps {
  rooms: Array<{
    id: string;
    name: string;
    objectCount: number;
  }>;
}

export function RoomMap({ rooms }: RoomMapProps) {
  return (
    <Card className="p-6 border border-border shadow-[var(--elevation-sm)] bg-card">
      <div className="mb-4">
        <h3 className="mb-2">Floor Plan Overview</h3>
        <p className="text-sm opacity-70">Real-time object detection across monitored areas</p>
      </div>

      {/* Simple Floor Plan Grid */}
      <div className="relative bg-primary/5 rounded-xl p-6 border border-border min-h-[400px]">
        {/* Grid layout for rooms */}
        <div className="grid grid-cols-2 gap-4 h-full">
          {/* Living Room - Top Left */}
          <div className="relative bg-card border-2 border-primary rounded-xl p-4 shadow-[var(--elevation-sm)] hover:border-primary/70 transition-all">
            <div className="absolute top-2 left-2 px-2 py-1 bg-primary text-primary-foreground rounded-lg text-xs">
              Living Room
            </div>
            <div className="absolute bottom-2 right-2 px-2 py-1 bg-chart-4 text-white rounded-lg text-xs">
              {rooms.find(r => r.name === "Living Room")?.objectCount || 0} objects
            </div>
            {/* Camera indicator */}
            <div className="absolute top-2 right-2 w-2 h-2 bg-chart-4 rounded-full animate-pulse"></div>
          </div>

          {/* Kitchen - Top Right */}
          <div className="relative bg-card border-2 border-primary rounded-xl p-4 shadow-[var(--elevation-sm)] hover:border-primary/70 transition-all">
            <div className="absolute top-2 left-2 px-2 py-1 bg-primary text-primary-foreground rounded-lg text-xs">
              Kitchen
            </div>
            <div className="absolute bottom-2 right-2 px-2 py-1 bg-chart-4 text-white rounded-lg text-xs">
              {rooms.find(r => r.name === "Kitchen")?.objectCount || 0} objects
            </div>
            <div className="absolute top-2 right-2 w-2 h-2 bg-chart-4 rounded-full animate-pulse"></div>
          </div>

          {/* Office - Bottom Left */}
          <div className="relative bg-card border-2 border-border rounded-xl p-4 opacity-60">
            <div className="absolute top-2 left-2 px-2 py-1 bg-muted-foreground text-white rounded-lg text-xs">
              Office
            </div>
            <div className="absolute bottom-2 right-2 px-2 py-1 bg-primary/20 text-foreground rounded-lg text-xs">
              Offline
            </div>
            <div className="absolute top-2 right-2 w-2 h-2 bg-border rounded-full"></div>
          </div>

          {/* Gym - Bottom Right */}
          <div className="relative bg-card border-2 border-primary rounded-xl p-4 shadow-[var(--elevation-sm)] hover:border-primary/70 transition-all">
            <div className="absolute top-2 left-2 px-2 py-1 bg-primary text-primary-foreground rounded-lg text-xs">
              Gym
            </div>
            <div className="absolute bottom-2 right-2 px-2 py-1 bg-chart-4 text-white rounded-lg text-xs">
              {rooms.find(r => r.name === "Gym")?.objectCount || 0} objects
            </div>
            <div className="absolute top-2 right-2 w-2 h-2 bg-chart-4 rounded-full animate-pulse"></div>
          </div>
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 flex items-center gap-4 bg-card px-3 py-2 rounded-lg border border-border shadow-[var(--elevation-sm)]">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-chart-4 rounded-full"></div>
            <span className="text-xs opacity-70">Active</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-border rounded-full"></div>
            <span className="text-xs opacity-70">Offline</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
