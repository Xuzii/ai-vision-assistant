import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ClockIcon, LocationIcon, ActivityIcon } from "./icons";
import type { ActivityCategory } from "./ActivityCard";
import { motion } from "motion/react";

interface TimelineActivity {
  time: string;
  person: string;
  location: string;
  activity: string;
  category: ActivityCategory;
  duration?: string;
}

interface TimelineProps {
  activities: TimelineActivity[];
}

const categoryColors: Record<ActivityCategory, string> = {
  Productivity: "bg-chart-1",
  Health: "bg-chart-4",
  Entertainment: "bg-chart-3",
  Social: "bg-chart-2",
  Other: "bg-chart-5",
};

const categoryEmojis: Record<ActivityCategory, string> = {
  Productivity: "💼",
  Health: "💪",
  Entertainment: "🎮",
  Social: "👥",
  Other: "📌",
};

export function Timeline({ activities }: TimelineProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-6 border border-border shadow-[var(--elevation-sm)] bg-card">
        <motion.div 
          className="mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="mb-2">Daily Timeline</h3>
          <p className="text-sm opacity-70">
            Your day at a glance - see all activities in chronological order
          </p>
        </motion.div>

      {/* Desktop: Alternating Timeline */}
      <div className="hidden md:block relative">
        {/* Central line */}
        <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-border transform -translate-x-1/2"></div>

        <div className="space-y-4">
          {activities.map((activity, index) => {
            const isLeft = index % 2 === 0;
            const colorClass = categoryColors[activity.category];

            return (
              <motion.div 
                key={index} 
                className="relative"
                initial={{ opacity: 0, x: isLeft ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ 
                  duration: 0.4, 
                  delay: index * 0.05,
                  ease: "easeOut"
                }}
              >
                {/* Time marker in center */}
                <motion.div 
                  className="absolute left-1/2 top-6 transform -translate-x-1/2 -translate-y-1/2 z-10"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.05 + 0.2, type: "spring", stiffness: 200 }}
                >
                  <div className={`w-4 h-4 rounded-full ${colorClass} border-4 border-card shadow-[var(--elevation-sm)]`}></div>
                </motion.div>

                {/* Activity card - alternating sides */}
                <div className={`flex ${isLeft ? 'justify-end pr-[52%]' : 'justify-start pl-[52%]'}`}>
                  <div className={`w-full ${isLeft ? 'text-right' : 'text-left'}`}>
                    {/* Time badge */}
                    <div className={`flex items-center gap-2 mb-2 ${isLeft ? 'justify-end' : 'justify-start'}`}>
                      <Badge variant="secondary" className="px-3 py-1 rounded-full bg-primary/10 text-primary border-0">
                        <ClockIcon className="w-3 h-3 mr-1.5 inline" />
                        {activity.time}
                      </Badge>
                      {activity.duration && (
                        <span className="text-xs opacity-60">{activity.duration}</span>
                      )}
                    </div>

                    {/* Activity card */}
                    <Card className="p-3 border border-border bg-card hover:shadow-lg hover:scale-[1.02] transition-all duration-300 cursor-pointer">
                      <div className={`flex items-start gap-2.5 ${isLeft ? 'flex-row-reverse' : 'flex-row'}`}>
                        <div className={`p-1.5 rounded-lg ${colorClass} bg-opacity-10 flex-shrink-0`}>
                          <span className="text-base">{categoryEmojis[activity.category]}</span>
                        </div>
                        <div className={`flex-1 min-w-0 ${isLeft ? 'text-right' : 'text-left'}`}>
                          <div className={`flex items-center gap-2 mb-1.5 ${isLeft ? 'justify-end' : 'justify-start'}`}>
                            <p className="font-medium text-foreground">{activity.person}</p>
                            <Badge variant="outline" className="text-xs px-2 py-0.5 rounded-full border-border">
                              {activity.category}
                            </Badge>
                          </div>
                          <p className="text-sm text-foreground mb-1.5">{activity.activity}</p>
                          <div className={`flex items-center gap-1.5 text-xs opacity-60 ${isLeft ? 'justify-end' : 'justify-start'}`}>
                            <LocationIcon className="w-3 h-3" />
                            <span>{activity.location}</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Mobile: Vertical Timeline */}
      <div className="block md:hidden relative pl-8">
        {/* Left line */}
        <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-border"></div>

        <div className="space-y-3">
          {activities.map((activity, index) => {
            const colorClass = categoryColors[activity.category];

            return (
              <motion.div 
                key={index} 
                className="relative"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ 
                  duration: 0.4, 
                  delay: index * 0.05,
                  ease: "easeOut"
                }}
              >
                {/* Time marker on left */}
                <motion.div 
                  className="absolute left-[-1.75rem] top-2"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.05 + 0.2, type: "spring", stiffness: 200 }}
                >
                  <div className={`w-3 h-3 rounded-full ${colorClass} border-2 border-card shadow-sm`}></div>
                </motion.div>

                <div className="space-y-2">
                  {/* Time badge */}
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="px-2 py-1 rounded-full bg-primary/10 text-primary border-0 text-xs">
                      <ClockIcon className="w-3 h-3 mr-1 inline" />
                      {activity.time}
                    </Badge>
                    {activity.duration && (
                      <span className="text-xs opacity-60">{activity.duration}</span>
                    )}
                  </div>

                  {/* Activity card */}
                  <Card className="p-3 border border-border bg-card hover:shadow-lg hover:scale-[1.02] transition-all duration-300 cursor-pointer">
                    <div className="flex items-start gap-2.5">
                      <div className={`p-1.5 rounded-lg ${colorClass} bg-opacity-10 flex-shrink-0`}>
                        <span className="text-base">{categoryEmojis[activity.category]}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <p className="text-sm font-medium text-foreground">{activity.person}</p>
                          <Badge variant="outline" className="text-xs px-2 py-0 rounded-full border-border">
                            {activity.category}
                          </Badge>
                        </div>
                        <p className="text-sm text-foreground mb-1.5">{activity.activity}</p>
                        <div className="flex items-center gap-1.5 text-xs opacity-60">
                          <LocationIcon className="w-3 h-3" />
                          <span>{activity.location}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
      </Card>
    </motion.div>
  );
}
