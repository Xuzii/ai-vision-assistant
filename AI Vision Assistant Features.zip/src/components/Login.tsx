import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { EyeIcon, ShieldIcon } from "./icons";

interface LoginProps {
  onLogin: (username: string, password: string) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(username, password);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 shadow-[var(--elevation-sm)]">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-primary shadow-[var(--elevation-sm)]">
              <EyeIcon className="w-8 h-8 text-primary-foreground" />
            </div>
          </div>
          <h2 className="mb-2">AI Vision Assistant</h2>
          <p className="opacity-70">
            Sign in to access your dashboard
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="username" className="block mb-2 opacity-70">
              Username
            </label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="w-full rounded-xl border border-border bg-input-background px-4 py-3"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="block mb-2 opacity-70">
              Password
            </label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full rounded-xl border border-border bg-input-background px-4 py-3"
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl py-6 shadow-[var(--elevation-sm)]"
          >
            Sign In
          </Button>
        </form>

        <div className="mt-6 flex items-center justify-center gap-2 text-sm">
          <ShieldIcon className="w-4 h-4 text-primary" />
          <span className="opacity-70">Protected by Tailscale VPN</span>
        </div>
      </Card>
    </div>
  );
}
