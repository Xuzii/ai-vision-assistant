import { Alert, AlertDescription } from "./ui/alert";
import { WifiOffIcon, AlertIcon, RefreshIcon } from "./icons";
import { motion, AnimatePresence } from "motion/react";

interface ConnectionStatusProps {
  isConnected: boolean;
  isReconnecting: boolean;
  failedCameras?: number;
  onReconnect?: () => void;
}

export function ConnectionStatus({ 
  isConnected, 
  isReconnecting, 
  failedCameras = 0,
  onReconnect 
}: ConnectionStatusProps) {
  return (
    <AnimatePresence mode="wait">
      {(!isConnected || isReconnecting) && (
        <motion.div
          key="connection-status"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          transition={{ type: "spring", stiffness: 200, damping: 20 }}
          className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-2xl px-4"
        >
        {isReconnecting ? (
          <Alert className="border-2 border-accent bg-accent/10 backdrop-blur-xl shadow-2xl">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="flex-shrink-0"
            >
              <RefreshIcon className="h-5 w-5 text-accent" />
            </motion.div>
            <AlertDescription className="flex items-center justify-between w-full">
              <div>
                <span className="font-medium text-accent">Reconnecting...</span>
                <p className="text-sm opacity-70 mt-1">
                  Attempting to restore connection with {failedCameras} camera{failedCameras !== 1 ? 's' : ''}
                </p>
              </div>
              <motion.div
                className="flex gap-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 bg-accent rounded-full"
                    animate={{ 
                      scale: [1, 1.5, 1],
                      opacity: [1, 0.5, 1]
                    }}
                    transition={{ 
                      duration: 1.5, 
                      repeat: Infinity,
                      delay: i * 0.2
                    }}
                  />
                ))}
              </motion.div>
            </AlertDescription>
          </Alert>
        ) : (
          <Alert variant="destructive" className="border-2 border-destructive bg-destructive/10 backdrop-blur-xl shadow-2xl">
            <WifiOffIcon className="h-5 w-5" />
            <AlertDescription className="flex items-center justify-between w-full">
              <div>
                <span className="font-medium">Connection Lost</span>
                <p className="text-sm opacity-70 mt-1">
                  {failedCameras} camera{failedCameras !== 1 ? 's are' : ' is'} offline. Check your network connection.
                </p>
              </div>
              {onReconnect && (
                <motion.button
                  onClick={onReconnect}
                  className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <RefreshIcon className="w-4 h-4" />
                  Retry
                </motion.button>
              )}
            </AlertDescription>
          </Alert>
        )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
