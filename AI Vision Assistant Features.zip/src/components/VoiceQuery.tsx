import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { MicIcon, MicOffIcon, MessageIcon, VolumeIcon } from "./icons";
import { useState } from "react";
import { Switch } from "./ui/switch";
import { motion, AnimatePresence } from "motion/react";

interface VoiceQueryProps {
  onQuery: (query: string) => void;
}

export function VoiceQuery({ onQuery }: VoiceQueryProps) {
  const [isListening, setIsListening] = useState(false);
  const [lastQuery, setLastQuery] = useState<string>("");
  const [response, setResponse] = useState<string>("");
  const [outputMode, setOutputMode] = useState<"text" | "voice">("text");
  const [isSpeaking, setIsSpeaking] = useState(false);

  const toggleListening = () => {
    if (!isListening) {
      setIsListening(true);
      // Simulate voice recognition
      setTimeout(() => {
        const mockQueries = [
          "What was I doing at 2 PM?",
          "How much time did I spend on productivity today?",
          "Where was I this morning?",
          "Show me my health activities"
        ];
        const query = mockQueries[Math.floor(Math.random() * mockQueries.length)];
        setLastQuery(query);
        setIsListening(false);
        
        // Mock response
        const mockResponses = [
          "You were in the Living Room working on your laptop for 45 minutes.",
          "You spent 3 hours and 20 minutes on productivity tasks today.",
          "This morning you were in the Kitchen from 7-8 AM, then moved to the Office.",
          "Today you had 2 workout sessions totaling 90 minutes."
        ];
        const responseText = mockResponses[Math.floor(Math.random() * mockResponses.length)];
        setResponse(responseText);
        onQuery(query);

        // If voice output is enabled, simulate speaking
        if (outputMode === "voice") {
          speakResponse(responseText);
        }
      }, 2000);
    } else {
      setIsListening(false);
    }
  };

  const speakResponse = (text: string) => {
    setIsSpeaking(true);
    // Simulate voice output duration
    const words = text.split(" ").length;
    const duration = words * 300; // ~300ms per word
    setTimeout(() => {
      setIsSpeaking(false);
    }, duration);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-6 border border-border shadow-[var(--elevation-sm)] bg-card">
        <motion.div 
          className="mb-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="mb-2">Voice Query</h3>
          <p className="text-sm opacity-70">
            Ask questions about your activities using voice
          </p>
        </motion.div>

      {/* Output Mode Toggle */}
      <div className="mb-4 p-4 bg-primary/5 rounded-xl border border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${outputMode === "text" ? "bg-primary/10" : "bg-transparent"}`}>
              <MessageIcon className={`w-4 h-4 ${outputMode === "text" ? "text-primary" : "opacity-50"}`} />
            </div>
            <div>
              <p className="text-sm font-medium">Output Mode</p>
              <p className="text-xs opacity-60">
                {outputMode === "text" ? "Text responses only" : "Voice + Text responses"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm opacity-70">Text</span>
            <Switch 
              checked={outputMode === "voice"}
              onCheckedChange={(checked) => setOutputMode(checked ? "voice" : "text")}
              className="data-[state=checked]:bg-chart-4"
            />
            <div className="flex items-center gap-1">
              <VolumeIcon className="w-4 h-4 opacity-70" />
              <span className="text-sm opacity-70">Voice</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="text-center mb-4">
        <div className="relative inline-flex items-center justify-center mb-4">
          {isListening && (
            <>
              <div className="absolute w-24 h-24 bg-destructive/20 rounded-full animate-ping"></div>
              <div className="absolute w-20 h-20 bg-destructive/30 rounded-full animate-pulse"></div>
            </>
          )}
          <Button
            size="lg"
            variant={isListening ? "destructive" : "default"}
            className="rounded-full w-20 h-20 shadow-[var(--elevation-sm)] relative z-10 border-0"
            onClick={toggleListening}
          >
            {isListening ? (
              <MicOffIcon className="w-7 h-7 animate-pulse" />
            ) : (
              <MicIcon className="w-7 h-7" />
            )}
          </Button>
        </div>
        <p className="text-sm font-medium">
          {isListening ? "🎙️ Listening..." : "Tap to ask about your activities"}
        </p>
      </div>

      <AnimatePresence>
        {lastQuery && (
          <motion.div 
            className="space-y-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <motion.div 
              className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm border border-border"
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              <p className="text-xs opacity-70 mb-2">You asked:</p>
              <p className="text-sm leading-relaxed text-foreground">{lastQuery}</p>
            </motion.div>
            {response && (
              <motion.div 
                className="p-4 bg-primary/10 rounded-xl border border-primary/20"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-primary">Response:</p>
                  {outputMode === "voice" && isSpeaking && (
                    <div className="flex items-center gap-2 text-xs text-chart-4">
                      <VolumeIcon className="w-3 h-3 animate-pulse" />
                      <span>Speaking...</span>
                    </div>
                  )}
                </div>
                <p className="text-sm leading-relaxed text-foreground">{response}</p>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      </Card>
    </motion.div>
  );
}
