import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { PlayIcon, PauseIcon, RefreshIcon } from "./icons";
import { useState } from "react";
import { motion } from "motion/react";

interface Process {
  id: string;
  name: string;
  status: "running" | "stopped" | "error";
  uptime: string;
  cpu: number;
  memory: number;
}

interface ProcessManagerProps {
  processes: Process[];
  onRestart: (id: string) => void;
  onStop: (id: string) => void;
  onStart: (id: string) => void;
}

export function ProcessManager({ processes, onRestart, onStop, onStart }: ProcessManagerProps) {
  const [restarting, setRestarting] = useState<string | null>(null);

  const handleRestart = (id: string) => {
    setRestarting(id);
    onRestart(id);
    setTimeout(() => setRestarting(null), 1500);
  };

  const getStatusColor = (status: Process["status"]) => {
    switch (status) {
      case "running": return "default";
      case "stopped": return "secondary";
      case "error": return "destructive";
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-6 border border-border shadow-[var(--elevation-sm)]">
        <motion.div 
          className="mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="mb-2">Process Manager</h3>
          <p className="text-sm opacity-70">
            Restart services without stopping everything
          </p>
        </motion.div>
        
        <div className="space-y-3">
          {processes.map((process, index) => (
            <motion.div 
              key={process.id} 
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-primary/5 rounded-xl hover:shadow-lg transition-all duration-300 border border-border hover:border-primary cursor-pointer"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.01, x: 4 }}
            >
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-2 h-2 rounded-full ${
                  process.status === 'running' ? 'bg-chart-4 animate-pulse' : 
                  process.status === 'error' ? 'bg-destructive' : 'bg-border'
                }`}></div>
                <h4 className="text-sm">{process.name}</h4>
                <Badge variant={getStatusColor(process.status)} className="text-xs rounded-full px-2.5">
                  {process.status}
                </Badge>
              </div>
              <div className="flex flex-wrap gap-4 text-xs">
                <span className="px-2.5 py-1 bg-card rounded-full opacity-70 border border-border">
                  ⏱ {process.uptime}
                </span>
                <span className="px-2.5 py-1 bg-card rounded-full opacity-70 border border-border">
                  💻 {process.cpu}%
                </span>
                <span className="px-2.5 py-1 bg-card rounded-full opacity-70 border border-border">
                  🧠 {process.memory}MB
                </span>
              </div>
            </div>
            
            <div className="flex gap-2">
              {process.status === "running" ? (
                <>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleRestart(process.id)}
                    disabled={restarting === process.id}
                    className="rounded-full"
                  >
                    <RefreshIcon className={`w-3 h-3 mr-1.5 ${restarting === process.id ? 'animate-spin' : ''}`} />
                    Restart
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => onStop(process.id)}
                    className="rounded-full"
                  >
                    <PauseIcon className="w-3 h-3 mr-1.5" />
                    Stop
                  </Button>
                </>
              ) : (
                <Button 
                  size="sm" 
                  variant="default"
                  onClick={() => onStart(process.id)}
                  className="rounded-full"
                >
                  <PlayIcon className="w-3 h-3 mr-1.5" />
                  Start
                </Button>
              )}
            </div>
          </motion.div>
        ))}
      </div>
      </Card>
    </motion.div>
  );
}
