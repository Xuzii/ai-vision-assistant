import { useState, useEffect } from 'react';

interface AppSettings {
  darkMode: boolean;
  refreshInterval: number;
}

const DEFAULT_SETTINGS: AppSettings = {
  darkMode: false,
  refreshInterval: 0, // Manual only (no auto-refresh)
};

const STORAGE_KEY = 'ai-vision-assistant-settings';

export function useSettings() {
  const [settings, setSettings] = useState<AppSettings>(() => {
    // Load settings from localStorage on initialization
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
        } catch (e) {
          console.error('Failed to parse settings:', e);
        }
      }
    }
    return DEFAULT_SETTINGS;
  });

  // Save settings to localStorage whenever they change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    }
  }, [settings]);

  // Apply dark mode class to document
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (settings.darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [settings.darkMode]);

  const updateSetting = <K extends keyof AppSettings>(
    key: K,
    value: AppSettings[K]
  ) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  return {
    settings,
    updateSetting,
    setDarkMode: (enabled: boolean) => updateSetting('darkMode', enabled),
    setRefreshInterval: (interval: number) => updateSetting('refreshInterval', interval),
  };
}
