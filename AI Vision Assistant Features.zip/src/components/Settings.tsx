import { Card } from "./ui/card";
import { Switch } from "./ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { MoonIcon, SunIcon, ClockIcon, RefreshIcon } from "./icons";
import { motion } from "motion/react";

interface SettingsProps {
  darkMode: boolean;
  refreshInterval: number;
  onDarkModeChange: (enabled: boolean) => void;
  onRefreshIntervalChange: (interval: number) => void;
}

export function Settings({ 
  darkMode, 
  refreshInterval, 
  onDarkModeChange, 
  onRefreshIntervalChange 
}: SettingsProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-6 border border-border shadow-[var(--elevation-sm)] bg-card">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="mb-2">UI Settings</h3>
          <p className="text-sm opacity-70 mb-6">
            Customize your experience with persistent preferences
          </p>
        </motion.div>

        <div className="space-y-6">
          {/* Dark Mode Toggle */}
          <motion.div 
            className="p-5 bg-primary/5 rounded-xl border border-border hover:border-primary/50 transition-all"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            whileHover={{ x: 4 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <motion.div 
                  className={`p-3 rounded-xl ${darkMode ? 'bg-primary/20' : 'bg-accent/20'} backdrop-blur-sm`}
                  animate={{ rotate: darkMode ? 0 : 180 }}
                  transition={{ duration: 0.5 }}
                >
                  {darkMode ? (
                    <MoonIcon className="w-5 h-5 text-primary" />
                  ) : (
                    <SunIcon className="w-5 h-5 text-accent" />
                  )}
                </motion.div>
                <div>
                  <h4 className="mb-1">Dark Mode</h4>
                  <p className="text-sm opacity-60">
                    {darkMode ? "Switch to light theme" : "Switch to dark theme"}
                  </p>
                </div>
              </div>
              <Switch 
                checked={darkMode}
                onCheckedChange={onDarkModeChange}
                className="data-[state=checked]:bg-primary"
              />
            </div>
          </motion.div>

          {/* Refresh Interval */}
          <motion.div 
            className="p-5 bg-primary/5 rounded-xl border border-border hover:border-primary/50 transition-all"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            whileHover={{ x: 4 }}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-4 flex-1">
                <div className="p-3 rounded-xl bg-chart-4/20 backdrop-blur-sm">
                  <RefreshIcon className="w-5 h-5 text-chart-4" />
                </div>
                <div className="flex-1">
                  <h4 className="mb-1">Auto Refresh Interval</h4>
                  <p className="text-sm opacity-60 mb-3">
                    How often to update camera feeds and activities
                  </p>
                  <Select 
                    value={refreshInterval.toString()} 
                    onValueChange={(value) => onRefreshIntervalChange(Number(value))}
                  >
                    <SelectTrigger className="w-full sm:w-[240px] rounded-xl border border-border bg-card backdrop-blur-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="5000">
                        <span className="flex items-center gap-2">
                          <ClockIcon className="w-4 h-4" />
                          Every 5 seconds
                        </span>
                      </SelectItem>
                      <SelectItem value="10000">
                        <span className="flex items-center gap-2">
                          <ClockIcon className="w-4 h-4" />
                          Every 10 seconds
                        </span>
                      </SelectItem>
                      <SelectItem value="30000">
                        <span className="flex items-center gap-2">
                          <ClockIcon className="w-4 h-4" />
                          Every 30 seconds
                        </span>
                      </SelectItem>
                      <SelectItem value="60000">
                        <span className="flex items-center gap-2">
                          <ClockIcon className="w-4 h-4" />
                          Every minute
                        </span>
                      </SelectItem>
                      <SelectItem value="0">
                        <span className="flex items-center gap-2">
                          <ClockIcon className="w-4 h-4" />
                          Manual only
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Settings Info */}
          <motion.div
            className="p-4 bg-accent/10 rounded-xl border border-accent/20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <p className="text-sm opacity-70">
              💾 Settings are automatically saved to your browser's local storage
            </p>
          </motion.div>
        </div>
      </Card>
    </motion.div>
  );
}
