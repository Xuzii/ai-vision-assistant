This Figma Make file includes components from [shadcn/ui](https://ui.shadcn.com/) used under [MIT license](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

This Figma Make file includes photos from [Unsplash](https://unsplash.com) used under [license](https://unsplash.com/license).

This work incorporates elements from [Photographer Portfolio Website UI Template - Dark Theme | Produce UI](https://www.figma.com/community/file/1324089527430438614), a community file created by Praha | Produce UI and licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

This work incorporates elements from [Sidebar with Interactive Prototype](https://www.figma.com/community/file/1126907064899468145), a community file created by Vinícius and licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).