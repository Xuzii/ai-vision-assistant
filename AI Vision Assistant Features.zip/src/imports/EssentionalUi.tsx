import svgPaths from "./svg-kket9nlqkn";

function LinearSettingsFineTuning() {
  return (
    <div className="relative shrink-0 size-[30px]" data-name="Linear / Settings, Fine Tuning /">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="Linear / Settings, Fine Tuning / ">
          <path d={svgPaths.p39ebcd00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1ca8a800} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p4621d40} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p792bc00} id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function IconCounterSticker() {
  return (
    <div className="absolute content-stretch flex gap-[10px] items-center right-[calc(50%-437.5px)] top-[117px]" data-name="Icon Counter Sticker">
      <LinearSettingsFineTuning />
      <p className="font-['Roboto:Medium',_sans-serif] font-medium leading-none relative shrink-0 text-[20px] text-nowrap text-white tracking-[0.4px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        139
      </p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="h-[30.29px] relative shrink-0 w-[110.72px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 111 31">
        <g id="Frame 1">
          <rect fill="var(--fill-0, white)" height="30.29" rx="15.145" width="110.72" />
          <g id="Line Duotone">
            <path d={svgPaths.p6ebec00} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p2528d400} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p8c85a80} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p28766200} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p2263c400} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p38b45080} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p11257b80} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p3fbe5b80} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p22901240} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p6d57600} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p3f2bd380} fill="var(--fill-0, #0E0E10)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame847() {
  return (
    <div className="content-stretch flex gap-[20px] items-center relative shrink-0">
      <p className="font-['Roboto:Medium',_sans-serif] font-medium leading-none relative shrink-0 text-[35px] text-nowrap text-white tracking-[0.7px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Essentional, UI
      </p>
      <div className="bg-white h-[15px] opacity-30 rounded-[16px] shrink-0 w-[2px]" />
      <Frame1 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start justify-center left-[calc(50%-437.5px)] top-[114px]" data-name="Header">
      <Frame847 />
    </div>
  );
}

function LineDuotoneEssentionalUiCheckCircle() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Check Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Check Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M8.5 12.5L10.5 14.5L15.5 9.5" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCloseCircle() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Close Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Close Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1b5498a0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiAddCircle() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Add Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Add Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p20feca80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiQuestionCircle() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Question Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Question Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pc072b80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="16" fill="var(--fill-0, white)" id="Vector_3" r="1" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiDangerCircle() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Danger Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Danger Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 7V13" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="16" fill="var(--fill-0, white)" id="Vector_3" r="1" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiInfoCircle() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Info Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Info Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 17V11" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="1" cy="1" fill="var(--fill-0, white)" id="Vector_3" r="1" transform="matrix(1 0 0 -1 11 9)" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMinusCircle() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Minus Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Minus Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 12H9" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiForbiddenCircle() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Forbidden Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Forbidden Circle">
          <path d="M18.5 5.5L5.50002 18.4998" id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="12" id="Vector_2" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiForbidden() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Forbidden">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Forbidden">
          <path d="M18.5 5.5L5.50002 18.4998" id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1d4d0d40} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiDanger() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Danger">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Danger">
          <path d="M12 7V13" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="16" fill="var(--fill-0, white)" id="Vector_2" r="1" />
          <path d={svgPaths.p33055840} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiDangerTriangle() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Danger Triangle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Danger Triangle">
          <path d={svgPaths.p251f8880} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 8V13" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="16" fill="var(--fill-0, white)" id="Vector_3" r="1" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCheckSquare() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Check Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Check Square">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M8.5 12.5L10.5 14.5L15.5 9.5" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCloseSquare() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Close Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Close Square">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p32c83b00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiAddSquare() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[229px]" data-name="Line Duotone / Essentional, UI / Add Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Add Square">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p20feca80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiQuestionSquare() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Question Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Question Square">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pc072b80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="16" fill="var(--fill-0, white)" id="Vector_3" r="1" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiDangerSquare() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Danger Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Danger Square">
          <path d="M12 7V13" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="12" cy="16" fill="var(--fill-0, white)" id="Vector_2" r="1" />
          <path d={svgPaths.p3d0bf80} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiInfoSquare() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Info Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Info Square">
          <path d="M12 17V11" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="1" cy="1" fill="var(--fill-0, white)" id="Vector_2" r="1" transform="matrix(1 0 0 -1 11 9)" />
          <path d={svgPaths.p3d0bf80} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMinusSquare() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Minus Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Minus Square">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 12H9" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiRevote() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Revote">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Revote">
          <path d={svgPaths.pdd9f270} fill="var(--stroke-0, white)" id="Vector" opacity="0.5" />
          <path d="M8.5 12.5L10.5 14.5L15.5 9.5" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMenuDotsCircle() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Menu Dots Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Menu Dots Circle">
          <g id="Vector">
            <path d={svgPaths.p1f8c0a00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p5e2b580} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3e843e00} fill="var(--fill-0, white)" />
          </g>
          <circle cx="12" cy="12" id="Vector_2" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMenuDotsSquare() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Menu Dots Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Menu Dots Square">
          <g id="Vector">
            <path d={svgPaths.p1f8c0a00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p5e2b580} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3e843e00} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p3d0bf80} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMenuDots() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Menu Dots">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Menu Dots ">
          <circle cx="5" cy="12" id="Vector" r="2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <circle cx="12" cy="12" id="Vector_2" opacity="0.5" r="2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <circle cx="19" cy="12" id="Vector_3" r="2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHome() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Home">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home ">
          <path d={svgPaths.p223ba100} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 18H9" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHome2() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Home 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home 2">
          <path d={svgPaths.p223ba100} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 15L12 18" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeSmile() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Home Smile">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home Smile">
          <path d={svgPaths.p223ba100} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p25eec400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeAdd() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Home Add">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home Add">
          <path d={svgPaths.p16f2e600} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3cfb4b00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeWiFi() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Home WiFi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home WiFi">
          <path d={svgPaths.p16f2e600} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p23d26f80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSmartHome() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[294px]" data-name="Line Duotone / Essentional, UI / Smart Home">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Smart Home">
          <path d={svgPaths.p37c2fa00} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p24e09400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2ae0e400} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p13df5800} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeAngle() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Home Angle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home Angle">
          <path d={svgPaths.p1da9d680} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 18H9" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeAngle2() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Home Angle 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home Angle 2">
          <path d={svgPaths.p2775f500} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 15L12 18" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeSmileAngle() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Home Smile Angle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home Smile Angle">
          <path d={svgPaths.p1da9d680} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p25eec400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeAddAngle() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Home Add Angle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home Add Angle">
          <path d={svgPaths.p1da9d680} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p30b54900} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHomeWiFiAngle() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Home WiFi Angle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Home WiFi Angle">
          <path d={svgPaths.p1da9d680} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p23d26f80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSmartHomeAngle() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Smart Home Angle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Smart Home Angle">
          <path d={svgPaths.pbf0cc0} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p24e09400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2ae0e400} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p13df5800} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryFullMinimalistic() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Full Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Full Minimalistic">
          <path d={svgPaths.p39b27c00} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M22 14L22 10" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3f4c7400} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p19b71880} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p32736700} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryHalfMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Half Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Half Minimalistic">
          <path d={svgPaths.p39b27c00} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3f4c7400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p19b71880} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M22 14L22 10" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryLowMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Low Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Low Minimalistic">
          <path d={svgPaths.p39b27c00} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3f4c7400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M22 14L22 10" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryChargeMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Charge Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Charge Minimalistic">
          <path d={svgPaths.p39b27c00} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M22 14L22 10" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M11.5 9L9 12H12.5L10 15" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryFull() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Full">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Full">
          <path d={svgPaths.p39b27c00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3f4c7400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p19b71880} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p32736700} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1a4bd8f0} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryHalf() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Half">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Half">
          <path d={svgPaths.p39b27c00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3f4c7400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p19b71880} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1a4bd8f0} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryLow() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Low">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Low">
          <path d={svgPaths.p39b27c00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3f4c7400} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1a4bd8f0} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBatteryCharge() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[359px]" data-name="Line Duotone / Essentional, UI / Battery Charge">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Battery Charge">
          <path d={svgPaths.p39b27c00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1a4bd8f0} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M11.5 9L9 12H12.5L10 15" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSliderVertical() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Slider Vertical">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Slider Vertical">
          <path d={svgPaths.p229e6880} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p508e480} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3709c300} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSliderVerticalMinimalistic() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Slider Vertical Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Slider Vertical Minimalistic">
          <path d={svgPaths.p229e6880} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M21 4.5L21 19.5" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M3 4.5L3 19.5" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSliderHorizontal() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Slider Horizontal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Slider Horizontal">
          <path d={svgPaths.p1a31b880} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2edcf930} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pbf3c800} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSliderMinimalisticHorizontal() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Slider Minimalistic Horizontal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Slider Minimalistic Horizontal">
          <path d={svgPaths.p1a31b880} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M4.5 3L19.5 3" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M4.5 21L19.5 21" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiDatabase() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Database">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Database">
          <path d="M4 18V6" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M20 6V18" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2ebaba70} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2b66e498} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p39884b00} id="Vector_5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTrafficEconomy() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Traffic Economy">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Traffic Economy">
          <path d={svgPaths.pb197240} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p20feca80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p16a3bd00} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTraffic() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Traffic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Traffic  ">
          <path d={svgPaths.pb197240} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p16a3bd00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCrownMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Crown Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Crown Minimalistic">
          <path d={svgPaths.p103796f0} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCrownStar() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Crown Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Crown Star">
          <path d={svgPaths.p103796f0} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3f7cf080} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCrownLine() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Crown Line">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Crown Line">
          <path d={svgPaths.p103796f0} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M9 18H15" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCrown() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Crown">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Crown ">
          <path d={svgPaths.p26249e80} fill="var(--stroke-0, white)" id="Vector" />
          <path d="M5 17.5H19" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPin() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Pin">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Pin">
          <path d={svgPaths.p74a09f0} fill="var(--stroke-0, white)" id="Vector" />
          <path d={svgPaths.pe25f280} fill="var(--stroke-0, white)" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPinList() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Pin List">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Pin List">
          <path d={svgPaths.p1f386580} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pd4db580} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M22 8H17" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M22 12.5H18" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M22 17H13" id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPinCircle() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[424px]" data-name="Line Duotone / Essentional, UI / Pin Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Pin Circle">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p14962f00} fill="var(--stroke-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTrashBinMinimalistic() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Trash Bin Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Trash Bin Minimalistic">
          <path d={svgPaths.p197779c0} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M20.5 6H3.49992" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1ea2de00} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M9.5 11L10 16" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M14.5 11L14 16" id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTrashBinTrash() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Trash Bin Trash">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Trash Bin Trash">
          <path d="M20.5 6H3.49992" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1ea2de00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M9.5 11L10 16" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M14.5 11L14 16" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p128d2000} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTrashBinMinimalistic2() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Trash Bin Minimalistic 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Trash Bin Minimalistic 2 ">
          <path d="M20.5 6H3.49992" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1ea2de00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p197779c0} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTrashBin2() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Trash Bin 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Trash Bin 2">
          <path d="M20.5 6H3.49992" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1ea2de00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p128d2000} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiShare() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Share">
          <path d={svgPaths.p342f8380} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M14.3206 16.8014L9 13.2898" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pc927500} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p38dcf900} id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2762ef40} id="Vector_5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiShareCircle() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Share Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Share Circle">
          <path d={svgPaths.p37352100} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1ecd1080} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p368fbdf0} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3e773180} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTarget() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Target">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Target">
          <path d={svgPaths.p3d2fbb00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M2 12L5 12" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M19 12L22 12" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 22L12 19" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 5L12 2" id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2f9750b4} id="Vector_6" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiWaterdrop() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Waterdrop">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Waterdrop">
          <path d={svgPaths.p219b780} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2cd87e80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPlate() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Plate">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Plate">
          <path d={svgPaths.p21df3680} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 5L12 3" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M8 10.5H16" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M8 14H13.5" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBroom() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Broom">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Broom">
          <path d={svgPaths.pfbbb400} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2d00600} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCopy() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Copy">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Copy">
          <path d={svgPaths.p1fa1d900} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p35b20c90} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSubtitles() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Subtitles">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Subtitles">
          <path d={svgPaths.p27262e00} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M10 16H6" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M14 13H18" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M14 16H12.5" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M9.5 13H11.5" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M18 16H16.5" id="Vector_6" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M6 13H7" id="Vector_7" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCat() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Cat">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cat">
          <path d={svgPaths.p170d1b80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p19768b00} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1694100} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p21bf7980} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p124e2a10} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pfb48b00} id="Vector_6" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1bd3b800} id="Vector_7" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p10e51a00} id="Vector_8" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiUmbrella() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[489px]" data-name="Line Duotone / Essentional, UI / Umbrella">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Umbrella">
          <path d={svgPaths.p256c8780} fill="var(--stroke-0, white)" id="Vector" />
          <path d={svgPaths.p3fca67e0} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiGhost() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Ghost">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Ghost">
          <path d={svgPaths.pa7a4900} fill="var(--fill-0, white)" id="Vector" />
          <ellipse cx="9" cy="10.5" fill="var(--fill-0, white)" id="Vector_2" rx="1" ry="1.5" />
          <path d={svgPaths.p3461f280} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiGhostSmile() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Ghost Smile">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Ghost Smile">
          <path d={svgPaths.p190c4780} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <ellipse cx="15" cy="9.5" fill="var(--fill-0, white)" id="Vector_2" rx="1" ry="1.5" />
          <ellipse cx="9" cy="9.5" fill="var(--fill-0, white)" id="Vector_3" rx="1" ry="1.5" />
          <path d={svgPaths.p3461f280} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPostsCarouselVertical() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Posts Carousel Vertical">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Posts Carousel Vertical">
          <path d={svgPaths.p2c258380} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p9468e00} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p6e439db} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPostsCarouselHorizontal() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Posts Carousel Horizontal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Posts Carousel Horizontal">
          <path d={svgPaths.p278d1900} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3d9cc900} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p28d01880} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBolt() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Bolt">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Bolt">
          <path d={svgPaths.p3ef3f600} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3a0f1500} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBoltCircle() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Bolt Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Bolt Circle">
          <path d={svgPaths.p1a0a8300} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pd01100} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPower() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Power">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Power">
          <path d="M12 2V6" id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pe06b180} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFuel() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Fuel">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Fuel">
          <path d={svgPaths.p3c992800} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2184fb00} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 11L16 10" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M9 11L8 10" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M15 17L16 18" id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M9 17L8 18" id="Vector_6" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1c171780} id="Vector_7" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFigma() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Figma">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Figma">
          <path d={svgPaths.pc356740} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2693f300} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3b829e00} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3ba82a0} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2ea9d000} id="Vector_5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiWinRar() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / WinRar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / WinRar">
          <path d={svgPaths.p3ffdde40} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2c074200} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 11L15 13" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHelp() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Help">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Help">
          <circle cx="12" cy="12" id="Vector" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <circle cx="12" cy="12" id="Vector_2" r="4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M15 9L19 5" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M5 19L9 15" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M9 9L5 5" id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M19 19L15 15" id="Vector_6" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFlag() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Flag">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Flag">
          <path d="M5 22V14V4V2" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p38c33a00} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFlag2() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Flag 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Flag 2">
          <path d="M5 22V14V4V2" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2e275f00} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBalloon() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[554px]" data-name="Line Duotone / Essentional, UI / Balloon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Balloon">
          <path d={svgPaths.p2a0d1f80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3a963700} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pd544600} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPaw() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Paw">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Paw">
          <path d={svgPaths.p2975c300} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pb49e800} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1a1d3500} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p24ff9300} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p285b7280} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCup() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Cup">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cup">
          <path d={svgPaths.p344edd00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p32593b88} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p23298b20} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 17V19" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pa486b2} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M18 22H6" id="Vector_6" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCupStar() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Cup Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cup Star">
          <path d={svgPaths.p344edd00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 16V19" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pa486b2} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p32593b88} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p23298b20} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3ef666f0} id="Vector_6" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M18 22H6" id="Vector_7" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCupFirst() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Cup First">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cup First">
          <path d={svgPaths.p344edd00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M11 8L12.5 6.5V10.5" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p32593b88} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p23298b20} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 16V19" id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pa486b2} id="Vector_6" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M18 22H6" id="Vector_7" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCupMusic() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Cup Music">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cup Music">
          <path d={svgPaths.p344edd00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M13 10.5V7.5V5" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <circle cx="11.5" cy="10.5" id="Vector_3" r="1.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p12ae39a0} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p32593b88} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p23298b20} id="Vector_6" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M12 16V19" id="Vector_7" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pa486b2} id="Vector_8" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M18 22H6" id="Vector_9" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSpecialEffects() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Special Effects">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Special Effects">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2fad2800} fill="var(--stroke-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiXxx() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / XXX">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / XXX">
          <path d={svgPaths.pb27580} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3d0bf80} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiExplicit() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Explicit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Explicit">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p33947400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHighQuality() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / High Quality">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / High Quality">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1d1b72c0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHighDefinition() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / High Definition">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / High Definition">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p15181800} fill="var(--stroke-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUi4K() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / 4K">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / 4K">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p33900ec0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCreativeCommons() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Creative Commons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Creative Commons">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3d01c500} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p39275460} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCopyright() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Copyright">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Copyright">
          <path d={svgPaths.pd01100} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2246d380} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiAugmentedReality() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[619px]" data-name="Line Duotone / Essentional, UI / Augmented Reality">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Augmented Reality">
          <path d={svgPaths.p3d0bf80} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p38fd1400} fill="var(--stroke-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHamburgerMenu() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Hamburger Menu">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Hamburger Menu">
          <path d="M20 7L4 7" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M20 12L4 12" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M20 17L4 17" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiReorder() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Reorder">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Reorder">
          <path d="M19 10L5 10" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M19 14L5 14" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M19 6L5 6" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M19 18L5 18" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSort() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Sort">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Sort">
          <path d="M22 7L2 7" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M19 12L5 12" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M16 17H8" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFilter() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Filter">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Filter">
          <path d={svgPaths.p1d660888} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p184cca00} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPaperBin() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Paper Bin">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Paper Bin">
          <path d={svgPaths.p2b6dc3f0} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M21 6H3" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p122fd840} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M19 19H5" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiGlasses() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Glasses">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Glasses">
          <circle cx="18" cy="16" id="Vector" r="4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <circle cx="6" cy="16" id="Vector_2" r="4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3923c600} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p349c0800} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p4113c00} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiScissors() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Scissors">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Scissors">
          <path d={svgPaths.p28d70800} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3c92db00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiScissorsSquare() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Scissors Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Scissors Square">
          <path d={svgPaths.p2f1d0380} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p337c1100} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3d0bf80} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBoxMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Box Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Box Minimalistic">
          <path d={svgPaths.p1572b480} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pb41c280} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBox() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Box">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Box">
          <path d={svgPaths.p1572b480} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pf7d6100} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFeed() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Feed">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Feed">
          <path d={svgPaths.p21bd7280} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.pce09800} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M7 6H12" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFerrisWheel() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Ferris Wheel">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Ferris Wheel">
          <circle cx="12" cy="11" id="Vector" r="2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p7a03e80} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p258da880} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p25ae9d80} id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p267cad00} id="Vector_5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2b887e00} id="Vector_6" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3beafd00} id="Vector_7" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M13.5 13L18.5 22" id="Vector_8" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M10.5 13L5.5 22" id="Vector_9" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1a2b5a00} id="Vector_10" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiPerfume() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Perfume">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Perfume">
          <path d={svgPaths.p8dbe880} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13 7H7" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p35b84700} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p10ab23c0} id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p197a0b00} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3bf2fb0} id="Vector_6" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1ec48200} id="Vector_7" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSleeping() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[684px]" data-name="Line Duotone / Essentional, UI / Sleeping">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Sleeping">
          <path d="M2 6V18" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p17b23b00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M2 16H22" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3c653000} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiDelivery() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Delivery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Delivery">
          <path d={svgPaths.p237ad600} fill="var(--stroke-0, white)" id="Vector" />
          <path d={svgPaths.p26547d80} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiGift() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Gift">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Gift">
          <path d="M22 12H2" id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 2V22" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1f7b6200} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2cdddd00} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p281a6f00} id="Vector_5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1759dd00} id="Vector_6" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3d0bf80} id="Vector_7" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMagicStick() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Magic Stick">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Magic Stick">
          <path d={svgPaths.p17014000} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p12cac400} fill="var(--stroke-0, white)" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMagicStick2() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Magic Stick 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Magic Stick 2">
          <path d={svgPaths.p3e68ba00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p2ace5500} fill="var(--stroke-0, white)" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMagicStick3() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Magic Stick 3">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Magic Stick 3">
          <path d={svgPaths.p3b19270} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d="M6 10L10 6" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3a60e680} id="Vector_3" stroke="var(--stroke-0, white)" />
          <path d={svgPaths.p287fe970} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" />
          <path d={svgPaths.p1ceb1b00} id="Vector_5" opacity="0.5" stroke="var(--stroke-0, white)" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSledgehammer() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Sledgehammer">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Sledgehammer">
          <path d={svgPaths.p289c6180} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p38179080} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1a147300} id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMagnet() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Magnet">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Magnet">
          <path d={svgPaths.pd11b400} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M17 2V7M17 17V22" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMagnetWave() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Magnet Wave">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Magnet Wave">
          <path d={svgPaths.p2fec700} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p16a0df00} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p29526000} id="Vector_3" opacity="0.7" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1e384720} id="Vector_4" opacity="0.4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFlashlight() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Flashlight">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Flashlight">
          <path d={svgPaths.p1f1db100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M15 10H9" id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 13V15" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M4.5 5H19.5" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiFlashlightOn() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Flashlight On">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Flashlight On">
          <path d={svgPaths.p3e740280} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M15 16H9" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M4.5 11H19.5" id="Vector_3" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 5V2" id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M8 5L6 3" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M16 5L18 3" id="Vector_6" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d="M12 19V21" id="Vector_7" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCursor() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Cursor">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cursor">
          <path d={svgPaths.p129cf580} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p39ca300} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCursorSquare() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Cursor Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cursor Square">
          <path d={svgPaths.p15eeb300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3d0bf80} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiCosmetic() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Cosmetic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Cosmetic">
          <path d={svgPaths.p66f200} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1e7cd200} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2e734a70} fill="var(--stroke-0, white)" id="Vector_3" />
          <path d={svgPaths.pc83aa00} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMirror() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Mirror">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Mirror">
          <path d={svgPaths.p3cf34b40} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p36071a80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiConfettiMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Confetti Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Confetti Minimalistic">
          <path d={svgPaths.p384b0900} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p31336880} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p36fc7ef0} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p17faf860} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p29982700} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <g id="Vector_6" opacity="0.5">
            <path d={svgPaths.p2bc33100} fill="var(--fill-0, white)" />
          </g>
          <g id="Vector_7">
            <path d={svgPaths.pada9300} fill="var(--fill-0, white)" />
          </g>
          <g id="Vector_8" opacity="0.5">
            <path d={svgPaths.p25539e00} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p117ed400} fill="var(--fill-0, white)" id="Vector_9" opacity="0.5" />
          <g id="Vector_10" opacity="0.5">
            <path d={svgPaths.p2696ac00} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiConfetti() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[749px]" data-name="Line Duotone / Essentional, UI / Confetti">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Confetti">
          <path d={svgPaths.p384b0900} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p31336880} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p36fc7ef0} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p28cea380} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2e22b00} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <g id="Vector_6" opacity="0.5">
            <path d={svgPaths.p15277c00} fill="var(--fill-0, white)" />
          </g>
          <g id="Vector_7" opacity="0.5">
            <path d={svgPaths.p18822200} fill="var(--fill-0, white)" />
          </g>
          <g id="Vector_8" opacity="0.5">
            <path d={svgPaths.p3a48ce00} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p117ed400} fill="var(--fill-0, white)" id="Vector_9" opacity="0.5" />
          <path d={svgPaths.p20ff1200} fill="var(--stroke-0, white)" id="Vector_10" />
          <path d={svgPaths.p37765d00} id="Vector_11" opacity="0.5" stroke="var(--stroke-0, white)" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHanger() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Hanger">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Hanger">
          <path d={svgPaths.p18a20d80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiHanger2() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Hanger 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Hanger 2">
          <path d={svgPaths.p3a8f2420} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3179c40} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiBody() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Body">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Body">
          <path d={svgPaths.p158a3900} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiTShirt() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / T-shirt">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / T-shirt">
          <path d={svgPaths.p10903900} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiSkirt() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Skirt">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Skirt">
          <path d={svgPaths.p37433300} fill="var(--stroke-0, white)" id="Vector" />
          <path d={svgPaths.p39817400} fill="var(--stroke-0, white)" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiAccessibility() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Accessibility">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Accessibility">
          <circle cx="12" cy="12" id="Vector" opacity="0.5" r="10" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p32cc9980} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p34ecddc0} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p322b01a0} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3949dd40} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMaskSad() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Mask Sad">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Mask Sad">
          <path d={svgPaths.p15a9f480} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1f446ee0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2ad57700} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p1be79c00} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMaskHapply() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Mask Happly">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Mask Happly">
          <path d={svgPaths.p15a9f480} id="Vector" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1f446ee0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2ad57700} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pcc20f00} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMasks() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Masks">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Masks">
          <path d={svgPaths.p34635b40} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p3a854400} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p7189400} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2ec2d760} id="Vector_4" opacity="0.5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p2636cd00} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p12636480} fill="var(--stroke-0, white)" id="Vector_6" opacity="0.5" />
          <path d={svgPaths.p3c7bfa80} id="Vector_7" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMentionSquare() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Mention Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Mention Square">
          <path d={svgPaths.p20fcb730} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.p3d0bf80} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function LineDuotoneEssentionalUiMentionCircle() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[814px]" data-name="Line Duotone / Essentional, UI / Mention Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Line Duotone / Essentional, UI / Mention Circle">
          <path d={svgPaths.p20fcb730} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="1.5" />
          <path d={svgPaths.pd01100} id="Vector_2" opacity="0.5" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

export default function EssentionalUi() {
  return (
    <div className="bg-[#0e0e10] overflow-clip relative rounded-[40px] size-full" data-name="Essentional, UI">
      <IconCounterSticker />
      <Header />
      <div className="absolute inset-[20px] rounded-[20px]">
        <div aria-hidden="true" className="absolute border border-[#1c1c21] border-solid inset-[-0.5px] pointer-events-none rounded-[20.5px]" />
      </div>
      <div className="absolute h-0 left-[10.43%] right-[10.52%] top-[179px]">
        <div className="absolute inset-[-0.5px_-0.06%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 874 2">
            <path d="M873 1H1" id="Rectangle 1656" stroke="var(--stroke-0, #1C1C21)" strokeLinecap="round" />
          </svg>
        </div>
      </div>
      <LineDuotoneEssentionalUiCheckCircle />
      <LineDuotoneEssentionalUiCloseCircle />
      <LineDuotoneEssentionalUiAddCircle />
      <LineDuotoneEssentionalUiQuestionCircle />
      <LineDuotoneEssentionalUiDangerCircle />
      <LineDuotoneEssentionalUiInfoCircle />
      <LineDuotoneEssentionalUiMinusCircle />
      <LineDuotoneEssentionalUiForbiddenCircle />
      <LineDuotoneEssentionalUiForbidden />
      <LineDuotoneEssentionalUiDanger />
      <LineDuotoneEssentionalUiDangerTriangle />
      <LineDuotoneEssentionalUiCheckSquare />
      <LineDuotoneEssentionalUiCloseSquare />
      <LineDuotoneEssentionalUiAddSquare />
      <LineDuotoneEssentionalUiQuestionSquare />
      <LineDuotoneEssentionalUiDangerSquare />
      <LineDuotoneEssentionalUiInfoSquare />
      <LineDuotoneEssentionalUiMinusSquare />
      <LineDuotoneEssentionalUiRevote />
      <LineDuotoneEssentionalUiMenuDotsCircle />
      <LineDuotoneEssentionalUiMenuDotsSquare />
      <LineDuotoneEssentionalUiMenuDots />
      <LineDuotoneEssentionalUiHome />
      <LineDuotoneEssentionalUiHome2 />
      <LineDuotoneEssentionalUiHomeSmile />
      <LineDuotoneEssentionalUiHomeAdd />
      <LineDuotoneEssentionalUiHomeWiFi />
      <LineDuotoneEssentionalUiSmartHome />
      <LineDuotoneEssentionalUiHomeAngle />
      <LineDuotoneEssentionalUiHomeAngle2 />
      <LineDuotoneEssentionalUiHomeSmileAngle />
      <LineDuotoneEssentionalUiHomeAddAngle />
      <LineDuotoneEssentionalUiHomeWiFiAngle />
      <LineDuotoneEssentionalUiSmartHomeAngle />
      <LineDuotoneEssentionalUiBatteryFullMinimalistic />
      <LineDuotoneEssentionalUiBatteryHalfMinimalistic />
      <LineDuotoneEssentionalUiBatteryLowMinimalistic />
      <LineDuotoneEssentionalUiBatteryChargeMinimalistic />
      <LineDuotoneEssentionalUiBatteryFull />
      <LineDuotoneEssentionalUiBatteryHalf />
      <LineDuotoneEssentionalUiBatteryLow />
      <LineDuotoneEssentionalUiBatteryCharge />
      <LineDuotoneEssentionalUiSliderVertical />
      <LineDuotoneEssentionalUiSliderVerticalMinimalistic />
      <LineDuotoneEssentionalUiSliderHorizontal />
      <LineDuotoneEssentionalUiSliderMinimalisticHorizontal />
      <LineDuotoneEssentionalUiDatabase />
      <LineDuotoneEssentionalUiTrafficEconomy />
      <LineDuotoneEssentionalUiTraffic />
      <LineDuotoneEssentionalUiCrownMinimalistic />
      <LineDuotoneEssentionalUiCrownStar />
      <LineDuotoneEssentionalUiCrownLine />
      <LineDuotoneEssentionalUiCrown />
      <LineDuotoneEssentionalUiPin />
      <LineDuotoneEssentionalUiPinList />
      <LineDuotoneEssentionalUiPinCircle />
      <LineDuotoneEssentionalUiTrashBinMinimalistic />
      <LineDuotoneEssentionalUiTrashBinTrash />
      <LineDuotoneEssentionalUiTrashBinMinimalistic2 />
      <LineDuotoneEssentionalUiTrashBin2 />
      <LineDuotoneEssentionalUiShare />
      <LineDuotoneEssentionalUiShareCircle />
      <LineDuotoneEssentionalUiTarget />
      <LineDuotoneEssentionalUiWaterdrop />
      <LineDuotoneEssentionalUiPlate />
      <LineDuotoneEssentionalUiBroom />
      <LineDuotoneEssentionalUiCopy />
      <LineDuotoneEssentionalUiSubtitles />
      <LineDuotoneEssentionalUiCat />
      <LineDuotoneEssentionalUiUmbrella />
      <LineDuotoneEssentionalUiGhost />
      <LineDuotoneEssentionalUiGhostSmile />
      <LineDuotoneEssentionalUiPostsCarouselVertical />
      <LineDuotoneEssentionalUiPostsCarouselHorizontal />
      <LineDuotoneEssentionalUiBolt />
      <LineDuotoneEssentionalUiBoltCircle />
      <LineDuotoneEssentionalUiPower />
      <LineDuotoneEssentionalUiFuel />
      <LineDuotoneEssentionalUiFigma />
      <LineDuotoneEssentionalUiWinRar />
      <LineDuotoneEssentionalUiHelp />
      <LineDuotoneEssentionalUiFlag />
      <LineDuotoneEssentionalUiFlag2 />
      <LineDuotoneEssentionalUiBalloon />
      <LineDuotoneEssentionalUiPaw />
      <LineDuotoneEssentionalUiCup />
      <LineDuotoneEssentionalUiCupStar />
      <LineDuotoneEssentionalUiCupFirst />
      <LineDuotoneEssentionalUiCupMusic />
      <LineDuotoneEssentionalUiSpecialEffects />
      <LineDuotoneEssentionalUiXxx />
      <LineDuotoneEssentionalUiExplicit />
      <LineDuotoneEssentionalUiHighQuality />
      <LineDuotoneEssentionalUiHighDefinition />
      <LineDuotoneEssentionalUi4K />
      <LineDuotoneEssentionalUiCreativeCommons />
      <LineDuotoneEssentionalUiCopyright />
      <LineDuotoneEssentionalUiAugmentedReality />
      <LineDuotoneEssentionalUiHamburgerMenu />
      <LineDuotoneEssentionalUiReorder />
      <LineDuotoneEssentionalUiSort />
      <LineDuotoneEssentionalUiFilter />
      <LineDuotoneEssentionalUiPaperBin />
      <LineDuotoneEssentionalUiGlasses />
      <LineDuotoneEssentionalUiScissors />
      <LineDuotoneEssentionalUiScissorsSquare />
      <LineDuotoneEssentionalUiBoxMinimalistic />
      <LineDuotoneEssentionalUiBox />
      <LineDuotoneEssentionalUiFeed />
      <LineDuotoneEssentionalUiFerrisWheel />
      <LineDuotoneEssentionalUiPerfume />
      <LineDuotoneEssentionalUiSleeping />
      <LineDuotoneEssentionalUiDelivery />
      <LineDuotoneEssentionalUiGift />
      <LineDuotoneEssentionalUiMagicStick />
      <LineDuotoneEssentionalUiMagicStick2 />
      <LineDuotoneEssentionalUiMagicStick3 />
      <LineDuotoneEssentionalUiSledgehammer />
      <LineDuotoneEssentionalUiMagnet />
      <LineDuotoneEssentionalUiMagnetWave />
      <LineDuotoneEssentionalUiFlashlight />
      <LineDuotoneEssentionalUiFlashlightOn />
      <LineDuotoneEssentionalUiCursor />
      <LineDuotoneEssentionalUiCursorSquare />
      <LineDuotoneEssentionalUiCosmetic />
      <LineDuotoneEssentionalUiMirror />
      <LineDuotoneEssentionalUiConfettiMinimalistic />
      <LineDuotoneEssentionalUiConfetti />
      <LineDuotoneEssentionalUiHanger />
      <LineDuotoneEssentionalUiHanger2 />
      <LineDuotoneEssentionalUiBody />
      <LineDuotoneEssentionalUiTShirt />
      <LineDuotoneEssentionalUiSkirt />
      <LineDuotoneEssentionalUiAccessibility />
      <LineDuotoneEssentionalUiMaskSad />
      <LineDuotoneEssentionalUiMaskHapply />
      <LineDuotoneEssentionalUiMasks />
      <LineDuotoneEssentionalUiMentionSquare />
      <LineDuotoneEssentionalUiMentionCircle />
    </div>
  );
}