import svgPaths from "./svg-2aomfpkq3k";

function Group2606() {
  return (
    <div className="basis-0 grid-cols-[max-content] grid-rows-[max-content] grow h-full inline-grid leading-[0] min-h-px min-w-px place-items-start relative shrink-0">
      <div className="[grid-area:1_/_1] flex items-center justify-center ml-0 mt-0 relative size-[148px]">
        <div className="flex-none rotate-[180deg] size-[148px]">
          <div className="relative size-full">
            <div className="absolute bottom-0 left-[11.11%] right-0 top-1/2">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 132 74">
                <path d={svgPaths.p20c46680} fill="var(--fill-0, #A155B9)" id="Ellipse 194" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="[grid-area:1_/_1] flex items-center justify-center ml-0 mt-0 relative size-[148px]">
        <div className="flex-none rotate-[180deg] size-[148px]">
          <div className="relative size-full">
            <div className="absolute bottom-[18.56%] left-0 right-[35.33%] top-0">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 96 121">
                <path d={svgPaths.p3f5c1d00} fill="var(--fill-0, #7987FF)" id="Ellipse 195" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="[grid-area:1_/_1] flex items-center justify-center ml-0 mt-0 relative size-[148px]">
        <div className="flex-none rotate-[180deg] size-[148px]">
          <div className="relative size-full">
            <div className="absolute bottom-[48.99%] left-[59.16%] right-0 top-[1.73%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 61 74">
                <path d={svgPaths.p126bde00} fill="var(--fill-0, #F765A3)" id="Ellipse 196" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="[grid-area:1_/_1] font-['Inter:Medium',_sans-serif] font-medium h-[14.225px] leading-[normal] ml-[59.839px] mt-[6.491px] not-italic relative text-[10px] text-center text-white translate-x-[-50%] w-[26.631px]">35%</p>
      <p className="[grid-area:1_/_1] font-['Inter:Medium',_sans-serif] font-medium h-[14.225px] leading-[normal] ml-[126.917px] mt-[103.863px] not-italic relative text-[10px] text-center text-white translate-x-[-50%] w-[26.631px]">50%</p>
      <p className="[grid-area:1_/_1] font-['Inter:Medium',_sans-serif] font-medium h-[14.225px] leading-[normal] ml-[24.136px] mt-[103.863px] not-italic relative text-[10px] text-center text-white translate-x-[-50%] w-[26.631px]">15%</p>
    </div>
  );
}

function IntetityColorCircle() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Intetity Color Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Intetity Color Circle">
          <circle cx="8" cy="8" fill="var(--fill-0, #7987FF)" id="Ellipse 2326" r="4" />
        </g>
      </svg>
    </div>
  );
}

function Component() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name>
      <p className="font-['Poppins:Medium',_sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">Content</p>
    </div>
  );
}

function DataContent() {
  return (
    <div className="bg-[rgba(255,255,255,0)] box-border content-stretch flex items-center overflow-clip px-0 py-px relative shrink-0" data-name="Data Content">
      <IntetityColorCircle />
      <Component />
    </div>
  );
}

function IntetityColorCircle1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Intetity Color Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Intetity Color Circle">
          <circle cx="8" cy="8" fill="var(--fill-0, #FFA5CB)" id="Ellipse 2326" r="4" />
        </g>
      </svg>
    </div>
  );
}

function Component1() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name>
      <p className="font-['Poppins:Medium',_sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">Content</p>
    </div>
  );
}

function DataContent1() {
  return (
    <div className="bg-[rgba(255,255,255,0)] box-border content-stretch flex items-center overflow-clip px-0 py-px relative shrink-0" data-name="Data Content">
      <IntetityColorCircle1 />
      <Component1 />
    </div>
  );
}

function IntetityColorCircle2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Intetity Color Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Intetity Color Circle">
          <circle cx="8" cy="8" fill="var(--fill-0, #E697FF)" id="Ellipse 2326" r="4" />
        </g>
      </svg>
    </div>
  );
}

function Component2() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name>
      <p className="font-['Poppins:Medium',_sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">Content</p>
    </div>
  );
}

function DataContent2() {
  return (
    <div className="bg-[rgba(255,255,255,0)] box-border content-stretch flex items-center overflow-clip px-0 py-px relative shrink-0" data-name="Data Content">
      <IntetityColorCircle2 />
      <Component2 />
    </div>
  );
}

function Frame2392() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <DataContent />
      <DataContent1 />
      <DataContent2 />
    </div>
  );
}

function Frame2568() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0">
      <div className="flex flex-col items-center justify-center size-full">
        <div className="box-border content-stretch flex flex-col gap-[10px] items-center justify-center p-[10px] relative size-full">
          <Frame2392 />
        </div>
      </div>
    </div>
  );
}

export default function NewApexCharts() {
  return (
    <div className="bg-white relative size-full" data-name="New ApexCharts">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center p-[10px] relative size-full">
          <Group2606 />
          <Frame2568 />
        </div>
      </div>
    </div>
  );
}