import svgPaths from "./svg-hz1sztwhvw";

function LinearSettingsFineTuning() {
  return (
    <div className="relative shrink-0 size-[30px]" data-name="Linear / Settings, Fine Tuning /">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="Linear / Settings, Fine Tuning / ">
          <path d={svgPaths.p39ebcd00} id="Vector" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p1ca8a800} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p4621d40} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
          <path d={svgPaths.p792bc00} id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function IconCounterSticker() {
  return (
    <div className="absolute content-stretch flex gap-[10px] items-center right-[calc(50%-437.5px)] top-[117px]" data-name="Icon Counter Sticker">
      <LinearSettingsFineTuning />
      <p className="font-['Roboto:Medium',_sans-serif] font-medium leading-none relative shrink-0 text-[20px] text-nowrap text-white tracking-[0.4px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        32
      </p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="h-[30.402px] relative shrink-0 w-[116.247px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 117 31">
        <g id="Frame 1">
          <rect fill="var(--fill-0, white)" height="30.402" rx="15.201" width="116.247" />
          <g id="Bold Duotone">
            <path d={svgPaths.p1e50c700} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p1ccdc380} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p19381700} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.pedf51c0} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p246ab400} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p155caf40} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p3f739000} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p28ca0e00} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p269d2f00} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p3ef3b0c0} fill="var(--fill-0, #0E0E10)" />
            <path d={svgPaths.p14d91ff0} fill="var(--fill-0, #0E0E10)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame847() {
  return (
    <div className="content-stretch flex gap-[20px] items-center relative shrink-0">
      <p className="font-['Roboto:Medium',_sans-serif] font-medium leading-none relative shrink-0 text-[35px] text-nowrap text-white tracking-[0.7px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Astronomy
      </p>
      <div className="bg-white h-[15px] opacity-30 rounded-[16px] shrink-0 w-[2px]" />
      <Frame1 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start justify-center left-[calc(50%-437.5px)] top-[114px]" data-name="Header">
      <Frame847 />
    </div>
  );
}

function BoldDuotoneAstronomyBlackHole() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Black Hole">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Black Hole">
          <g id="Union" opacity="0.5">
            <path d={svgPaths.p2032ca30} fill="var(--fill-0, white)" />
            <path d={svgPaths.p151ac7c0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p35719000} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2afb5280} fill="var(--fill-0, white)" />
            <path d={svgPaths.p177eb200} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2cbd6a80} fill="var(--fill-0, white)" />
            <path d={svgPaths.p803e80} fill="var(--fill-0, white)" />
            <path d={svgPaths.p5805580} fill="var(--fill-0, white)" />
            <path d={svgPaths.p19001b00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3540b400} fill="var(--fill-0, white)" />
            <path d={svgPaths.p31619d00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p18367f00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2ed17100} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2599f7f0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p17539a00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p29cb7b00} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p39311700} fill="var(--fill-0, white)" id="Union_2" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyBlackHole2() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Black Hole 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Black Hole 2">
          <g id="Union">
            <path d={svgPaths.p377c4c40} fill="var(--fill-0, white)" />
            <path d={svgPaths.p5d22900} fill="var(--fill-0, white)" />
            <path d={svgPaths.pd734200} fill="var(--fill-0, white)" />
            <path d={svgPaths.p21e0b900} fill="var(--fill-0, white)" />
            <path d={svgPaths.p1b5b4780} fill="var(--fill-0, white)" />
            <path d={svgPaths.p1d26a300} fill="var(--fill-0, white)" />
            <path d={svgPaths.p36ae9670} fill="var(--fill-0, white)" />
          </g>
          <g id="Union_2" opacity="0.5">
            <path d={svgPaths.p14cac00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p15c2bc80} fill="var(--fill-0, white)" />
            <path d={svgPaths.p1d740880} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3dbe800} fill="var(--fill-0, white)" />
            <path d={svgPaths.p8608c00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2c620670} fill="var(--fill-0, white)" />
            <path d={svgPaths.p36657600} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2d532700} fill="var(--fill-0, white)" />
            <path d={svgPaths.p22aa0600} fill="var(--fill-0, white)" />
            <path d={svgPaths.p392c5ef0} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyBlackHole3() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Black Hole 3">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Black Hole 3">
          <path d={svgPaths.p37d77e80} fill="var(--fill-0, white)" id="Union" />
          <g id="Union_2" opacity="0.5">
            <path d={svgPaths.p7006c80} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3b147500} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyMen() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Men">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Men">
          <circle cx="10" cy="14" fill="var(--fill-0, white)" id="Ellipse 582" opacity="0.5" r="8" />
          <path d={svgPaths.p727e500} fill="var(--fill-0, white)" id="Subtract" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyWomen() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Women">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Women">
          <circle cx="12" cy="9" fill="var(--fill-0, white)" id="Ellipse 581" opacity="0.5" r="7" />
          <path d={svgPaths.p363b5f80} fill="var(--fill-0, white)" id="Subtract" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyAtom() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Atom">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Atom">
          <path d={svgPaths.p241c3700} fill="var(--fill-0, white)" id="Vector" opacity="0.3" />
          <path d={svgPaths.p2653c300} fill="var(--fill-0, white)" id="Vector_2" opacity="0.3" />
          <path d={svgPaths.p687b440} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyPlanet() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Planet">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Planet ">
          <path d={svgPaths.p1ad51580} fill="var(--fill-0, white)" id="Vector" opacity="0.5" />
          <path d={svgPaths.p26e10b00} fill="var(--fill-0, white)" id="Vector (Stroke)" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyPlanet2() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Planet 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Planet 2">
          <path d={svgPaths.p1ad51580} fill="var(--fill-0, white)" id="Vector" opacity="0.5" />
          <g id="Vector (Stroke)">
            <path d={svgPaths.p2a43900} fill="var(--fill-0, white)" />
            <path clipRule="evenodd" d={svgPaths.pa7e7f80} fill="var(--fill-0, white)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyPlanet3() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Planet 3">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Planet 3">
          <g id="Subtract">
            <path d={svgPaths.p14b87c00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3e1e2c80} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p3649880} fill="var(--fill-0, white)" id="Subtract_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyPlanet4() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Planet 4">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Planet 4">
          <g id="Subtract">
            <path d={svgPaths.p3cc58c00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p19436800} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p1ae26c80} fill="var(--fill-0, white)" id="Subtract_2" opacity="0.5" />
          <path d={svgPaths.p2fe5f000} fill="var(--fill-0, white)" id="Vector" opacity="0.5" />
          <g id="Vector_2" opacity="0.5"></g>
          <path d={svgPaths.p2621f200} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyEarth() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Earth">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Earth">
          <circle cx="12" cy="12" fill="var(--fill-0, white)" id="Vector" opacity="0.5" r="10" />
          <path d={svgPaths.p27bf6700} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p50e1980} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyAsteroid() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Asteroid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Asteroid">
          <path d={svgPaths.p1fabe500} fill="var(--fill-0, white)" id="Vector" opacity="0.5" />
          <path d={svgPaths.p3bc43d80} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p2a45fa00} fill="var(--fill-0, white)" id="Vector_3" />
          <path d={svgPaths.p537ea80} fill="var(--fill-0, white)" id="Vector_4" />
          <path d={svgPaths.p2f805500} fill="var(--fill-0, white)" id="Vector_5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomySatellite() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Satellite">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Satellite">
          <path clipRule="evenodd" d={svgPaths.p27287660} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector (Stroke)" opacity="0.5" />
          <g id="Subtract">
            <path d={svgPaths.p14489800} fill="var(--fill-0, white)" />
            <path d={svgPaths.p10aeab00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p28400100} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyInfinity() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[229px]" data-name="Bold Duotone / Astronomy / Infinity">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Infinity">
          <path clipRule="evenodd" d={svgPaths.p15d26200} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector (Stroke)" />
          <path d={svgPaths.p3228a7ac} fill="var(--fill-0, white)" id="Subtract" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyRocket() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Rocket">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Rocket">
          <path clipRule="evenodd" d={svgPaths.p29062b00} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
          <g id="Vector_2" opacity="0.5">
            <path d={svgPaths.p3cb00600} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3d61d300} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyRocket2() {
  return (
    <div className="absolute left-[calc(50%-176.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Rocket 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Rocket 2">
          <g id="Vector">
            <path clipRule="evenodd" d={svgPaths.p194bc700} fill="var(--fill-0, white)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p325bd880} fill="var(--fill-0, white)" fillRule="evenodd" />
          </g>
          <g id="Vector_2" opacity="0.5">
            <path d={svgPaths.p12542d00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p36fe6500} fill="var(--fill-0, white)" />
          </g>
          <g id="Vector_3" opacity="0.5">
            <path d={svgPaths.p2e001400} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3d0f2b00} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarCircle() {
  return (
    <div className="absolute left-[calc(50%-111.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Star Circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Circle">
          <path d={svgPaths.p3d2fbb00} fill="var(--fill-0, white)" id="Subtract" opacity="0.5" />
          <path d={svgPaths.p3ed92a70} fill="var(--fill-0, white)" id="Subtract_2" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarAngle() {
  return (
    <div className="absolute left-[calc(50%-46.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Star Angle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Angle">
          <g id="Subtract" opacity="0.5">
            <path d={svgPaths.pbb8a300} fill="var(--fill-0, white)" />
            <path d={svgPaths.p11320000} fill="var(--fill-0, white)" />
            <path d={svgPaths.p2e0f3cc0} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p18ce2d00} fill="var(--fill-0, white)" id="Subtract_2" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarFall() {
  return (
    <div className="absolute left-[calc(50%+18.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Star Fall">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Fall">
          <path d={svgPaths.p29762e00} fill="var(--fill-0, white)" id="Star 7" />
          <path d={svgPaths.p226828c0} fill="var(--fill-0, white)" id="Star 8" opacity="0.5" />
          <path d={svgPaths.p34277100} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p370994f0} fill="var(--fill-0, white)" id="Subtract" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarRainbow() {
  return (
    <div className="absolute left-[calc(50%+148.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Star Rainbow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Rainbow">
          <path d={svgPaths.p6a44700} fill="var(--fill-0, white)" id="Vector" />
          <g id="Subtract" opacity="0.5">
            <path d={svgPaths.pe6e0600} fill="var(--fill-0, white)" />
            <path d={svgPaths.p268ad800} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3260abf0} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStar() {
  return (
    <div className="absolute left-[calc(50%+213.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star">
          <path clipRule="evenodd" d={svgPaths.p2aa68480} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector (Stroke)" />
          <g id="Vector (Stroke)_2" opacity="0.5">
            <path d={svgPaths.p1d20ae00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p38d62a00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p20c0acc0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3faea200} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStars() {
  return (
    <div className="absolute left-[calc(50%+278.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Stars">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Stars">
          <path d={svgPaths.p15e3ee00} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p4a06a00} fill="var(--fill-0, white)" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarsLine() {
  return (
    <div className="absolute left-[calc(50%+343.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Stars Line">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Stars Line">
          <path d={svgPaths.p3061ea80} fill="var(--fill-0, white)" id="Vector" />
          <g id="Vector_2" opacity="0.5">
            <path clipRule="evenodd" d={svgPaths.p29048300} fill="var(--fill-0, white)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p30d00b00} fill="var(--fill-0, white)" fillRule="evenodd" />
          </g>
          <path d={svgPaths.p169f0800} fill="var(--fill-0, white)" id="Star 7" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarsMinimalistic() {
  return (
    <div className="absolute left-[calc(50%+408.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Stars Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Stars Minimalistic">
          <path d={svgPaths.p9a72900} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p10bb300} fill="var(--fill-0, white)" id="Star 7" opacity="0.5" />
          <path clipRule="evenodd" d={svgPaths.p517a200} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector (Stroke)" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarFallMinimalistic() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[359px]" data-name="Bold Duotone / Astronomy / Star Fall Minimalistic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Fall Minimalistic">
          <path d={svgPaths.p12d0af00} fill="var(--fill-0, white)" id="Vector" />
          <path clipRule="evenodd" d={svgPaths.p10604600} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarFallMinimalistic2() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[359px]" data-name="Bold Duotone / Astronomy / Star Fall Minimalistic 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Fall Minimalistic 2">
          <path d={svgPaths.p1313acf0} fill="var(--fill-0, white)" id="Vector" />
          <path clipRule="evenodd" d={svgPaths.p227441f0} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarFall2() {
  return (
    <div className="absolute left-[calc(50%+83.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / Star Fall 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Fall 2">
          <path d={svgPaths.p2d7e3ff2} fill="var(--fill-0, white)" id="Vector" />
          <g id="Subtract" opacity="0.5">
            <path d={svgPaths.p2f426cf0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p1e45da00} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarRing() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[359px]" data-name="Bold Duotone / Astronomy / Star Ring">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Ring">
          <path clipRule="evenodd" d={svgPaths.p34c41f00} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p12e9ae00} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector (Stroke)_2" opacity="0.5" />
          <path clipRule="evenodd" d={svgPaths.p19a7a800} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector 1114 (Stroke)" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyStarRings() {
  return (
    <div className="absolute left-[calc(50%-241.5px)] size-[24px] top-[359px]" data-name="Bold Duotone / Astronomy / Star Rings">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / Star Rings">
          <path clipRule="evenodd" d={svgPaths.pe50ecc0} fill="var(--fill-0, white)" fillRule="evenodd" id="Union" opacity="0.5" />
          <path d={svgPaths.p794db80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyUfo() {
  return (
    <div className="absolute left-[calc(50%-436.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / UFO">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / UFO">
          <path clipRule="evenodd" d={svgPaths.pe9952f0} fill="var(--fill-0, white)" fillRule="evenodd" id="Subtract" />
          <path d={svgPaths.pbf39d80} fill="var(--fill-0, white)" id="Subtract_2" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyUfo2() {
  return (
    <div className="absolute left-[calc(50%-371.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / UFO 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / UFO 2">
          <g id="Subtract">
            <path clipRule="evenodd" d={svgPaths.p1e3a7a00} fill="var(--fill-0, white)" fillRule="evenodd" />
            <path d={svgPaths.p129cad00} fill="var(--fill-0, white)" />
          </g>
          <g id="Subtract_2" opacity="0.5">
            <path d={svgPaths.p661c80} fill="var(--fill-0, white)" />
            <path d={svgPaths.p5547cf0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3d5bb100} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function BoldDuotoneAstronomyUfo3() {
  return (
    <div className="absolute left-[calc(50%-306.5px)] size-[24px] top-[294px]" data-name="Bold Duotone / Astronomy / UFO 3">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Bold Duotone / Astronomy / UFO 3">
          <g id="Subtract">
            <path clipRule="evenodd" d={svgPaths.p60ad300} fill="var(--fill-0, white)" fillRule="evenodd" />
            <path d={svgPaths.pee27680} fill="var(--fill-0, white)" />
          </g>
          <g id="Subtract_2" opacity="0.5">
            <path d={svgPaths.pbb47880} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3007f780} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3d5ca670} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

export default function Astronomy() {
  return (
    <div className="bg-[#0e0e10] overflow-clip relative rounded-[40px] size-full" data-name="Astronomy">
      <IconCounterSticker />
      <div className="absolute inset-[20px] rounded-[20px]">
        <div aria-hidden="true" className="absolute border border-[#1c1c21] border-solid inset-[-0.5px] pointer-events-none rounded-[20.5px]" />
      </div>
      <div className="absolute h-0 left-[10.43%] right-[10.52%] top-[179px]">
        <div className="absolute inset-[-0.5px_-0.06%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 874 2">
            <path d="M873 1H1" id="Rectangle 1656" stroke="var(--stroke-0, #1C1C21)" strokeLinecap="round" />
          </svg>
        </div>
      </div>
      <Header />
      <BoldDuotoneAstronomyBlackHole />
      <BoldDuotoneAstronomyBlackHole2 />
      <BoldDuotoneAstronomyBlackHole3 />
      <BoldDuotoneAstronomyMen />
      <BoldDuotoneAstronomyWomen />
      <BoldDuotoneAstronomyAtom />
      <BoldDuotoneAstronomyPlanet />
      <BoldDuotoneAstronomyPlanet2 />
      <BoldDuotoneAstronomyPlanet3 />
      <BoldDuotoneAstronomyPlanet4 />
      <BoldDuotoneAstronomyEarth />
      <BoldDuotoneAstronomyAsteroid />
      <BoldDuotoneAstronomySatellite />
      <BoldDuotoneAstronomyInfinity />
      <BoldDuotoneAstronomyRocket />
      <BoldDuotoneAstronomyRocket2 />
      <BoldDuotoneAstronomyStarCircle />
      <BoldDuotoneAstronomyStarAngle />
      <BoldDuotoneAstronomyStarFall />
      <BoldDuotoneAstronomyStarRainbow />
      <BoldDuotoneAstronomyStar />
      <BoldDuotoneAstronomyStars />
      <BoldDuotoneAstronomyStarsLine />
      <BoldDuotoneAstronomyStarsMinimalistic />
      <BoldDuotoneAstronomyStarFallMinimalistic />
      <BoldDuotoneAstronomyStarFallMinimalistic2 />
      <BoldDuotoneAstronomyStarFall2 />
      <BoldDuotoneAstronomyStarRing />
      <BoldDuotoneAstronomyStarRings />
      <BoldDuotoneAstronomyUfo />
      <BoldDuotoneAstronomyUfo2 />
      <BoldDuotoneAstronomyUfo3 />
    </div>
  );
}