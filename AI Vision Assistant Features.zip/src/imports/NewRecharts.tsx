function Group2411() {
  return (
    <div className="[grid-area:1_/_1] h-[95.862px] ml-0 mt-0 relative w-[290.001px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 290 96">
        <g id="Group 2411">
          <rect height="94.8623" id="Rectangle 2" stroke="var(--stroke-0, #F1F1F1)" strokeDasharray="2 2" width="289.001" x="0.5" y="0.5" />
          <path d="M0 31.9541H290.001" id="Vector 2" stroke="var(--stroke-0, #F1F1F1)" strokeDasharray="2 2" />
          <path d="M0 63.9082H290.001" id="Vector 4" stroke="var(--stroke-0, #F1F1F1)" strokeDasharray="2 2" />
          <g id="Group 2438">
            <path d="M74.5147 0L74.5147 94.8637" id="Vector 5" stroke="var(--stroke-0, #F1F1F1)" strokeDasharray="2 2" />
            <path d="M147.015 0L147.015 94.8637" id="Vector 6" stroke="var(--stroke-0, #F1F1F1)" strokeDasharray="2 2" />
            <path d="M219.515 0L219.515 94.8637" id="Vector 23" stroke="var(--stroke-0, #F1F1F1)" strokeDasharray="2 2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group2455() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[0.694%] mt-[62.596%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[18.621px] ml-0 mt-[16.759px] w-[12.083px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[4.966px] ml-0 mt-[11.793px] w-[12.083px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[11.793px] ml-0 mt-0 w-[12.083px]" />
    </div>
  );
}

function Group2456() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[5.903%] mt-[42.776%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[28.621px] ml-0 mt-[25.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[7.632px] ml-0 mt-[18.126px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[18.126px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2457() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[10.87%] mt-[26.085%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[37.042px] ml-0 mt-[33.338px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[9.878px] ml-0 mt-[23.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[23.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2458() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[15.838%] mt-[0.006%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[50.2px] ml-0 mt-[45.18px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[13.387px] ml-0 mt-[31.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[31.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2459() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[20.805%] mt-[35.474%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[32.305px] ml-0 mt-[29.074px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[8.615px] ml-0 mt-[20.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[20.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2460() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[25.441%] mt-[62.596%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[18.621px] ml-0 mt-[16.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[4.966px] ml-0 mt-[11.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[11.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2461() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[30.409%] mt-[42.776%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[28.621px] ml-0 mt-[25.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[7.632px] ml-0 mt-[18.127px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[18.126px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2462() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[35.376%] mt-[26.085%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[37.042px] ml-0 mt-[33.338px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[9.878px] ml-0 mt-[23.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[23.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2463() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[40.343%] mt-[0.006%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[50.2px] ml-0 mt-[45.18px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[13.387px] ml-0 mt-[31.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[31.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2464() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[45.311%] mt-[35.474%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[32.305px] ml-0 mt-[29.074px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[8.615px] ml-0 mt-[20.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[20.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2465() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[50.278%] mt-[62.596%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[18.621px] ml-0 mt-[16.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[4.966px] ml-0 mt-[11.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[11.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2466() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[55.245%] mt-[42.776%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[28.621px] ml-0 mt-[25.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[7.632px] ml-0 mt-[18.127px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[18.126px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2467() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[60.213%] mt-[26.085%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[37.042px] ml-0 mt-[33.338px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[9.878px] ml-0 mt-[23.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[23.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2468() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[65.18%] mt-[0.006%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[50.2px] ml-0 mt-[45.18px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[13.387px] ml-0 mt-[31.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[31.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2469() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[70.147%] mt-[35.474%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[32.305px] ml-0 mt-[29.074px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[8.615px] ml-0 mt-[20.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[20.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2470() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[75.115%] mt-[62.596%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[18.621px] ml-0 mt-[16.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[4.966px] ml-0 mt-[11.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[11.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2471() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[80.082%] mt-[42.776%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[28.621px] ml-0 mt-[25.759px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[7.632px] ml-0 mt-[18.127px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[18.126px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2472() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[85.049%] mt-[26.085%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[37.042px] ml-0 mt-[33.338px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[9.878px] ml-0 mt-[23.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[23.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2473() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[90.018%] mt-[0.006%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[50.2px] ml-0 mt-[45.18px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[13.387px] ml-0 mt-[31.793px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[31.793px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2474() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[94.984%] mt-[35.474%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#7987ff] h-[32.305px] ml-0 mt-[29.074px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#ffa5cb] h-[8.615px] ml-0 mt-[20.459px] w-[11.524px]" />
      <div className="[grid-area:1_/_1] bg-[#e697ff] h-[20.46px] ml-0 mt-0 w-[11.524px]" />
    </div>
  );
}

function Group2636() {
  return (
    <div className="basis-0 grid-cols-[max-content] grid-rows-[max-content] grow inline-grid leading-[0] min-h-px min-w-px place-items-start relative shrink-0 w-full">
      <Group2411 />
      <Group2455 />
      <Group2456 />
      <Group2457 />
      <Group2458 />
      <Group2459 />
      <Group2460 />
      <Group2461 />
      <Group2462 />
      <Group2463 />
      <Group2464 />
      <Group2465 />
      <Group2466 />
      <Group2467 />
      <Group2468 />
      <Group2469 />
      <Group2470 />
      <Group2471 />
      <Group2472 />
      <Group2473 />
      <Group2474 />
    </div>
  );
}

function Frame2560() {
  return (
    <div className="basis-0 content-stretch flex gap-[10px] grow items-center justify-center min-h-px min-w-px relative shrink-0">
      <p className="basis-0 font-['Inter:Regular',_sans-serif] font-normal grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[10px] text-black text-center">q1</p>
    </div>
  );
}

function Frame2561() {
  return (
    <div className="basis-0 content-stretch flex gap-[10px] grow items-center justify-center min-h-px min-w-px relative shrink-0">
      <p className="basis-0 font-['Inter:Regular',_sans-serif] font-normal grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[10px] text-black text-center">q2</p>
    </div>
  );
}

function Frame2562() {
  return (
    <div className="basis-0 content-stretch flex gap-[10px] grow items-center justify-center min-h-px min-w-px relative shrink-0">
      <p className="basis-0 font-['Inter:Regular',_sans-serif] font-normal grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[10px] text-black text-center">q3</p>
    </div>
  );
}

function Frame2563() {
  return (
    <div className="basis-0 content-stretch flex gap-[10px] grow items-center justify-center min-h-px min-w-px relative shrink-0">
      <p className="basis-0 font-['Inter:Regular',_sans-serif] font-normal grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[10px] text-black text-center">q4</p>
    </div>
  );
}

function Timeline() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Timeline">
      <Frame2560 />
      <Frame2561 />
      <Frame2562 />
      <Frame2563 />
    </div>
  );
}

export default function NewRecharts() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="New Recharts">
      <Group2636 />
      <Timeline />
    </div>
  );
}