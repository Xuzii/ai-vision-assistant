import svgPaths from "./svg-5wmiulxjyz";

/**
 * @figmaAssetKey d40048342303a7a51faa7b7835e53c01106db58c
 */
function Search({ className }: { className?: string }) {
  return (
    <div className={className} data-name="search">
      <div className="absolute inset-[12.5%_20.83%_20.83%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-7.317%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p26ca7cf0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[69.38%_12.5%_12.5%_69.38%]" data-name="Vector">
        <div className="absolute inset-[-26.913%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d="M4.71563 4.71563L1 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey d77e6ba662fe6f8d9df5928cf3b2b6407f7e28e2
 */
function Bell({ className }: { className?: string }) {
  return (
    <div className={className} data-name="bell">
      <div className="absolute inset-[8.33%_12.5%_29.17%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-7.8%_-6.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 15">
            <path d={svgPaths.pd6f7280} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[87.5%_42.79%_8.35%_42.79%]" data-name="Vector">
        <div className="absolute inset-[-117.51%_-33.84%_-117.49%_-33.84%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 3">
            <path d={svgPaths.p97fb100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey 02502c6617dc23e496ffa0642833eda0b24b315b
 */
function HelpCircle({ className }: { className?: string }) {
  return (
    <div className={className} data-name="help-circle">
      <div className="absolute inset-[8.333%]" data-name="Vector">
        <div className="absolute inset-[-5.854%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
            <path d={svgPaths.p2a170700} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey bd5181ce31e9e05428416c8e1697bc4a3eef705d
 */
function Settings({ className }: { className?: string }) {
  return (
    <div className={className} data-name="settings">
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-19.512%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
            <path d={svgPaths.p76d3500} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[4.167%]" data-name="Vector">
        <div className="absolute inset-[-5.322%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21 21">
            <path d={svgPaths.p365cbe00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey 7036a479771e2bfe13a6a0b1041724881f7ec23f
 */
function Sliders({ className }: { className?: string }) {
  return (
    <div className={className} data-name="sliders">
      <div className="absolute inset-[12.5%_4.17%]" data-name="Vector">
        <div className="absolute inset-[-6.5%_-5.32%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21 18">
            <path d={svgPaths.p26bb8d80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey 1e3f56e187291a92cc3006dbeeecb06f23e9e7a3
 */
function Layers({ className }: { className?: string }) {
  return (
    <div className={className} data-name="layers">
      <div className="absolute inset-[8.333%]" data-name="Vector">
        <div className="absolute inset-[-5.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
            <path d={svgPaths.p23226100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey 2baef108102bb29ca37fa437eec57fbeacf2e9d2
 */
function Box({ className }: { className?: string }) {
  return (
    <div className={className} data-name="box">
      <div className="absolute inset-[8.34%_12.5%_8%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.83%_-6.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 20">
            <path d={svgPaths.p3da6a3c0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey 0cc6c7cb5b0fe1b846d88b7ab1f75a96bdea3fda
 */
function FileText({ className }: { className?: string }) {
  return (
    <div className={className} data-name="file-text">
      <div className="absolute inset-[7.32%_18.7%_9.35%_14.63%]" data-name="Vector">
        <div className="absolute inset-[-5.85%_-7.32%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 20">
            <path d={svgPaths.p307f3b80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

/**
 * @figmaAssetKey ac885203fc3cc0ec62ae534cc296fb9d6df665fe
 */
function Home({ className }: { className?: string }) {
  return (
    <div className={className} data-name="home">
      <div className="absolute inset-[8.33%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.85%_-6.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 20">
            <path d={svgPaths.p2f079e80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[8.33%] left-[37.5%] right-[37.5%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-11.71%_-19.51%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 11">
            <path d="M1 9.54167V1H6.125V9.54167" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Section() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 w-full" data-name="Section">
      <p className="font-['Inter:Regular',_sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#9e9e9e] text-[14px] w-full">These are the Sidebar project defaults. The colors were selected to avoid eye strain caused by oversaturated colors. The Inter font family meets good reading and accessibility practices. The icons are from the Feather Icons library.</p>
    </div>
  );
}

function ChildSections() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="Child sections">
      <Section />
    </div>
  );
}

function Section1() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="Section">
      <p className="font-['Inter:Bold',_sans-serif] font-bold leading-[1.2] not-italic relative shrink-0 text-[#9e9e9e] text-[30px] w-full">Style Guide</p>
      <ChildSections />
    </div>
  );
}

function LogoFrame1() {
  return (
    <div className="relative shrink-0 size-[52.5px]" data-name="Logo/Frame 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
        <g id="Logo/Frame 1">
          <path d={svgPaths.p278e7280} fill="var(--fill-0, #BFB2FF)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function LogoCont() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex gap-[8px] items-center ml-0 mt-0 relative" data-name="logo-cont">
      <LogoFrame1 />
      <p className="font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[1.2] not-italic relative shrink-0 text-[24px] text-nowrap text-white whitespace-pre">Untitled</p>
    </div>
  );
}

function LogoFrame2() {
  return (
    <div className="relative shrink-0 size-[52.5px]" data-name="Logo/Frame 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
        <g id="Logo/Frame 1">
          <path d={svgPaths.p278e7280} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function LogoCont1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex gap-[8px] items-center ml-[193.5px] mt-0 relative" data-name="logo-cont">
      <LogoFrame2 />
      <p className="font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[1.2] not-italic relative shrink-0 text-[24px] text-nowrap text-white whitespace-pre">Untitled</p>
    </div>
  );
}

function Logos() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Logos">
      <LogoCont />
      <LogoCont1 />
    </div>
  );
}

function Group58() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#bfb2ff] h-[15px] ml-0 mt-0 w-[224.5px]" />
      <div className="[grid-area:1_/_1] bg-white h-[15px] ml-[224px] mt-0 w-[224.5px]" />
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-0 mt-[30px] not-italic relative text-[16px] text-[grey] w-[60.846px]">BFB2FF</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[224px] mt-[30px] not-italic relative text-[16px] text-[grey] w-[60.846px]">FFFFFF</p>
    </div>
  );
}

function Group59() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-[36.313%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#1e1e1e] h-[15px] ml-0 mt-0 w-[112.25px]" />
      <div className="[grid-area:1_/_1] bg-[#333333] h-[15px] ml-[112.25px] mt-0 w-[112.25px]" />
      <div className="[grid-area:1_/_1] bg-[grey] h-[15px] ml-[224.5px] mt-0 w-[112.25px]" />
      <div className="[grid-area:1_/_1] flex h-[15px] items-center justify-center ml-[336.75px] mt-0 relative w-[112.25px]">
        <div className="flex-none h-[15px] rotate-[180deg] w-[112.25px]">
          <div className="bg-[#9e9e9e] size-full" />
        </div>
      </div>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-0 mt-[30px] not-italic relative text-[16px] text-[grey] w-[60.846px]">1E1E1E</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[112.25px] mt-[29.669px] not-italic relative text-[16px] text-[grey] w-[86.023px]">333333</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[224.5px] mt-[29.669px] not-italic relative text-[16px] text-[grey] w-[82.876px]">808080</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[336.75px] mt-[30px] not-italic relative text-[16px] text-[grey] w-[60.846px]">9E9E9E</p>
    </div>
  );
}

function Group60() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-[72.626%] place-items-start relative">
      <div className="[grid-area:1_/_1] bg-[#b5ffc1] h-[15px] ml-0 mt-0 w-[112.25px]" />
      <div className="[grid-area:1_/_1] bg-[#b5daff] h-[15px] ml-[112.25px] mt-0 w-[112.25px]" />
      <div className="[grid-area:1_/_1] bg-[#ffdc81] h-[15px] ml-[224.5px] mt-0 w-[112.25px]" />
      <div className="[grid-area:1_/_1] flex h-[15px] items-center justify-center ml-[336.75px] mt-0 relative w-[112.25px]">
        <div className="flex-none h-[15px] rotate-[180deg] w-[112.25px]">
          <div className="bg-[#ff9580] size-full" />
        </div>
      </div>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-0 mt-[30px] not-italic relative text-[16px] text-[grey] w-[60.846px]">B5FFC1</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[112.25px] mt-[29.669px] not-italic relative text-[16px] text-[grey] w-[86.023px]">B5DAFF</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[224.5px] mt-[29.669px] not-italic relative text-[16px] text-[grey] w-[82.876px]">FFDC81</p>
      <p className="[grid-area:1_/_1] font-['Consolas:Regular',_sans-serif] leading-[normal] ml-[336.75px] mt-[30px] not-italic relative text-[16px] text-[grey] w-[60.846px]">FF9580</p>
    </div>
  );
}

function Colors() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative" data-name="Colors">
      <Group58 />
      <Group59 />
      <Group60 />
    </div>
  );
}

function Colors1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Colors">
      <Colors />
    </div>
  );
}

function Group56() {
  return (
    <div className="absolute bottom-0 contents font-['Inter:Regular',_sans-serif] font-normal leading-[normal] left-0 not-italic right-0 text-[#9e9e9e] text-[16px] text-nowrap top-[51.06%] whitespace-pre">
      <p className="absolute bottom-[28.72%] left-0 right-[20.71%] top-[51.06%]">abcdefghijklmnopqrstuvwxyz</p>
      <p className="absolute bottom-0 left-0 right-0 top-[79.79%] uppercase">abcdefghijklmnopqrstuvwxyz</p>
    </div>
  );
}

function Type() {
  return (
    <div className="h-[94px] relative shrink-0 w-[280px]" data-name="Type">
      <p className="absolute bottom-[57.45%] font-['Inter:Medium',_sans-serif] font-medium leading-[normal] left-0 not-italic right-[68.21%] text-[40px] text-nowrap text-white top-[-8.51%] whitespace-pre">Inter</p>
      <Group56 />
    </div>
  );
}

function IconWhite() {
  return (
    <div className="h-[20.5px] relative shrink-0 w-[276.5px]" data-name="icon-white">
      <Home className="absolute left-[calc(50%+96px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <FileText className="absolute left-1/2 overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <Box className="absolute left-[calc(50%+64px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <Layers className="absolute left-[calc(50%-32px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <Sliders className="absolute left-[calc(50%-96px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <Settings className="absolute left-[calc(50%-128px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <HelpCircle className="absolute left-[calc(50%-64px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <Bell className="absolute left-[calc(50%+32px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
      <Search className="absolute left-[calc(50%+128px)] overflow-clip size-[20.5px] top-1/2 translate-x-[-50%] translate-y-[-50%]" />
    </div>
  );
}

export default function StyleGuide() {
  return (
    <div className="bg-[#2c2c2c] relative rounded-[6px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.06)] size-full" data-name="style-guide">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[24px] items-start overflow-clip p-[32px] relative size-full">
          <Section1 />
          <p className="font-['Inter:Bold',_sans-serif] font-bold leading-[1.2] min-w-full not-italic relative shrink-0 text-[#9e9e9e] text-[20px] w-[min-content]">Logo</p>
          <Logos />
          <div className="bg-[#333333] h-[2px] shrink-0 w-[449px]" />
          <p className="font-['Inter:Bold',_sans-serif] font-bold leading-[1.2] min-w-full not-italic relative shrink-0 text-[#9e9e9e] text-[20px] w-[min-content]">Colors</p>
          <Colors1 />
          <div className="bg-[#333333] h-[2px] shrink-0 w-[449px]" />
          <p className="font-['Inter:Bold',_sans-serif] font-bold leading-[1.2] min-w-full not-italic relative shrink-0 text-[#9e9e9e] text-[20px] w-[min-content]">Type</p>
          <Type />
          <div className="bg-[#333333] h-[2px] shrink-0 w-[449px]" />
          <p className="font-['Inter:Bold',_sans-serif] font-bold leading-[1.2] min-w-full not-italic relative shrink-0 text-[#9e9e9e] text-[20px] w-[min-content]">Icons</p>
          <IconWhite />
        </div>
      </div>
    </div>
  );
}