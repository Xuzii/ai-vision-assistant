
  # AI Vision Assistant Features

  This is a code bundle for AI Vision Assistant Features. The original project is available at https://www.figma.com/design/5Dkm1KqSW6c6dWlbgsnAjZ/AI-Vision-Assistant-Features.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  